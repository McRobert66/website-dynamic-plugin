# About Us Plugin - Template Reference

**Version:** 1.0.0  
**Author:** Black Angel Team  
**Purpose:** TEMPLATE EXAMPLE per tutti i futuri plugin del CMS

---

## 📋 Overview

Questo plugin serve come **TEMPLATE COMPLETO** e **RIFERIMENTO** per la creazione di tutti i futuri plugin per Website Dynamic CMS. Include tutte le best practices, automazioni e standard stabiliti.

### Funzionalità Implementate

- ✅ **Pagina Frontend** "Chi Siamo" completamente responsive
- ✅ **Gestione Team** con membri, ruoli, bio e social links
- ✅ **Admin Panel** completo con AdminLTE 4
- ✅ **Widget** per sidebar/aree widget
- ✅ **Sistema Multilingual** completo (IT/EN)
- ✅ **Installazione Automatica** con DB, page, widget, menu
- ✅ **Disinstallazione Completa** con pulizia totale DB
- ✅ **CSS Esternalizzato** con variabili tema
- ✅ **JavaScript Esternalizzato** per admin e frontend
- ✅ **AJAX** per tutte le operazioni admin

---

## 📁 Struttura Directory (STANDARD)

```
/plugins/about/
├── about.php                # Main file (auto-loaded dal CMS)
├── router.php               # Frontend routing (?page=about)
├── install.php              # ⭐ INSTALLAZIONE AUTOMATICA
├── uninstall.php            # ⭐ DISINSTALLAZIONE COMPLETA
├── plugin.json              # Metadata plugin
├── README.md                # Questa documentazione
│
├── admin/
│   ├── index.php           # Admin panel principale
│   └── ajax/               # Tutti gli endpoint AJAX
│       ├── save_content.php
│       ├── add_member.php
│       ├── edit_member.php
│       ├── get_member.php
│       ├── delete_member.php
│       ├── toggle_member.php
│       └── update_order.php
│
├── templates/
│   └── index.php           # Template frontend page
│
├── widgets/                 # ⭐ Root level (NON in templates/)
│   └── widget-about.php    # Widget display
│
├── assets/
│   ├── css/                # ⭐ TUTTO CSS esterno
│   │   ├── about.css       # Frontend styles
│   │   ├── about-admin.css # Admin styles
│   │   └── widget-about.css # Widget styles
│   └── js/                 # ⭐ TUTTO JS esterno
│       ├── about-admin.js  # Admin functionality
│       └── widget-about.js # Widget JS (se necessario)
│
└── languages/              # ⭐ File traduzione
    ├── it/
    │   └── about.php       # return ['key' => 'valore'];
    └── en/
        └── about.php       # return ['key' => 'value'];
```

---

## 🔧 Installazione Automatica

### install.php - REQUIREMENTS

**DEVE eseguire automaticamente:**

1. **Creare tabelle database** (esegue SQL)
2. **Inserire in `plugins`** (attivazione plugin)
3. **Creare pagina** in tabella `pages`
4. **Creare widget** in tabella `widgets` con `type='widget'`
5. **Aggiungere al menu** in tabella `menu_items`

```php
function about_install() {
    $db = Database::getInstance();
    $db->beginTransaction();
    
    // 1. CREATE TABLES
    // 2. INSERT INTO plugins
    // 3. INSERT INTO pages
    // 4. INSERT INTO widgets
    // 5. INSERT INTO menu_items
    
    $db->commit();
}
```

### Database Schema

```sql
CREATE TABLE about_content (
  id INT PRIMARY KEY AUTO_INCREMENT,
  title TEXT COMMENT 'Supporta @@it@@...@@en@@...',
  content LONGTEXT,
  mission TEXT,
  vision TEXT,
  founded_year INT(4),
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE about_team (
  id INT PRIMARY KEY AUTO_INCREMENT,
  user_id INT COMMENT 'Link opzionale a users',
  name VARCHAR(255) NOT NULL,
  role VARCHAR(255) NOT NULL COMMENT 'Multilingual',
  bio TEXT COMMENT 'Multilingual',
  avatar VARCHAR(255),
  email VARCHAR(255),
  social_links TEXT COMMENT 'JSON: {twitter, discord, steam, github}',
  display_order INT DEFAULT 0,
  is_active TINYINT(1) DEFAULT 1,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  KEY (display_order)
);
```

---

## 🗑️ Disinstallazione Completa

### uninstall.php - REQUIREMENTS

**DEVE rimuovere completamente:**

1. **DROP TABLE** `about_content`, `about_team`
2. **DELETE FROM** `plugins` WHERE name='about'
3. **DELETE FROM** `pages` WHERE slug='about'
4. **DELETE FROM** `widgets` WHERE name='about'
5. **DELETE FROM** `menu_items` WHERE page_id IN (...)
6. **DELETE FROM** `widget_assignments` (se esiste)

```php
function about_uninstall() {
    $db = Database::getInstance();
    $db->beginTransaction();
    
    // Get page ID
    $pageId = ...;
    
    // 1. DROP TABLES
    // 2. DELETE FROM plugins
    // 3. DELETE FROM pages
    // 4. DELETE FROM widgets
    // 5. DELETE FROM menu_items
    
    $db->commit();
}
```

---

## 🎨 CSS con Variabili Tema

**TUTTI gli stili DEVONO essere in file esterni** in `/assets/css/`.

**SEMPRE usare variabili CSS del tema:**

```css
/* about.css - Frontend */
.about-page {
    color: var(--text-primary);
    background: var(--card-bg);
    border: 1px solid var(--border-color);
    border-radius: var(--radius-card);
    box-shadow: var(--shadow);
    transition: var(--transition);
}

.about-page:hover {
    box-shadow: var(--shadow-lg);
}
```

### Variabili Disponibili

```css
/* Colori */
--text-primary, --text-secondary, --text-muted
--card-bg, --body-bg, --bg-secondary
--border-color
--primary, --success, --danger, --warning, --info

/* Border Radius */
--radius-card (12px)
--radius-btn (8px)
--radius-card-inner (8px)

/* Shadows */
--shadow, --shadow-sm, --shadow-lg, --shadow-xl

/* Transitions */
--transition (0.3s)
--transition-fast (0.15s)
```

**❌ MAI usare:**
- Stili inline `<style>` nei template
- Colori hardcoded `#333`, `rgb()`
- Valori fissi invece di variabili

---

## 📜 JavaScript Esternalizzato

**TUTTO JavaScript DEVE essere in file esterni** in `/assets/js/`.

**❌ MAI usare `<script>` inline** nei template.

```javascript
// about-admin.js
document.addEventListener('DOMContentLoaded', function() {
    
    // Content form submit
    const contentForm = document.getElementById('content-form');
    if (contentForm) {
        contentForm.addEventListener('submit', handleSubmit);
    }
    
    // Edit buttons
    document.querySelectorAll('.edit-member').forEach(btn => {
        btn.addEventListener('click', handleEdit);
    });
});
```

**Caricamento nel template:**

```php
<script src="<?php echo $base_url; ?>/plugins/about/assets/js/about-admin.js"></script>
```

---

## 🌍 Sistema Multilingual

### File Traduzione

**languages/it/about.php:**
```php
<?php
return [
    'title' => 'Chi Siamo',
    'our_team' => 'Il Nostro Team',
    'read_more' => 'Leggi di più',
    // ...
];
```

**languages/en/about.php:**
```php
<?php
return [
    'title' => 'About Us',
    'our_team' => 'Our Team',
    'read_more' => 'Read more',
    // ...
];
```

### Uso nel Codice

```php
// Load translation
$lang = loadLanguage('about');

// Use in template
echo $lang['title']; // "Chi Siamo" or "About Us"

// Database content with multilingual
"@@it@@Fondatore@@en@@Founder@@de@@Gründer"
// Use translateText() to extract current language
echo translateText($content['role']);
```

---

## 🧩 Widget Creation

### Database Registration

```sql
INSERT INTO widgets (name, title, icon, content, type, status) VALUES (
    'about',
    '@@it@@Chi Siamo in Breve@@en@@About Us Brief',
    'fa-info-circle',
    'include WD_ROOT . \'/plugins/about/widgets/widget-about.php\';',
    'widget',
    1
);
```

**⚠️ IMPORTANTE:**
- `type='widget'` (moderno, NON 'php')
- `content` usa `include WD_ROOT . '...'`
- Nessun tag PHP `<?php ?>` nel content

### Widget File Structure

```php
<?php
// widget-about.php
if (!defined('WD_EXEC')) die('Access denied');

$lang = loadLanguage('about');
$db = Database::getInstance();

// Get data
$content = $db->query("SELECT * FROM about_content WHERE id=1")->fetch();
?>

<link rel="stylesheet" href="<?php echo $base_url; ?>/plugins/about/assets/css/widget-about.css">

<div class="widget-about">
    <div class="widget-header">
        <h3><?php echo $lang['widget_title']; ?></h3>
    </div>
    <div class="widget-content">
        <!-- Widget content -->
    </div>
</div>
```

---

## 🎯 Admin Panel Standard

### Layout AdminLTE 4

```php
<?php
include '../admin_header.php'; // ⭐ usa admin_header_CORRETTO.php
?>

<link rel="stylesheet" href="<?php echo $base_url; ?>/plugins/about/assets/css/about-admin.css">

<div class="content-wrapper">
    <div class="content-header">
        <div class="gradient-header">
            <h1><i class="fas fa-icon"></i> Title</h1>
            <p>Description</p>
        </div>
    </div>
    
    <section class="content">
        <!-- Stats cards -->
        <!-- Nav pills tabs -->
        <!-- Tab content -->
    </section>
</div>

<script src="<?php echo $base_url; ?>/plugins/about/assets/js/about-admin.js"></script>

<?php include '../admin_footer.php'; ?>
```

### AJAX Endpoint Standard

```php
<?php
define('WD_EXEC', true);
require_once '../../../../config.php';

header('Content-Type: application/json');

// Check admin session
if (!isset($_SESSION['admin_logged_in'])) {
    echo json_encode(['success' => false, 'message' => 'Non autorizzato']);
    exit;
}

$db = Database::getInstance();
$lang = loadLanguage('about');

try {
    // Process request
    // ...
    
    echo json_encode([
        'success' => true,
        'message' => $lang['success_message']
    ]);
} catch (Exception $e) {
    echo json_encode([
        'success' => false,
        'message' => $lang['error_occurred'] . ': ' . $e->getMessage()
    ]);
}
```

---

## ✅ Checklist per Nuovi Plugin

Quando crei un nuovo plugin usando questo template:

### Struttura File
- [ ] Directory structure corretta
- [ ] `about.php` main file presente
- [ ] `router.php` per routing frontend
- [ ] `plugin.json` con metadata
- [ ] `README.md` documentazione

### Installazione/Disinstallazione
- [ ] `install.php` completo e automatico
- [ ] Crea tabelle DB
- [ ] Inserisce in `plugins` table
- [ ] Crea pagina in `pages`
- [ ] Crea widget in `widgets`
- [ ] Aggiunge menu item
- [ ] `uninstall.php` completo
- [ ] Rimuove TUTTE le tabelle
- [ ] Rimuove da TUTTE le tabelle di sistema

### CSS & JavaScript
- [ ] TUTTO CSS in `/assets/css/`
- [ ] Usa variabili CSS del tema
- [ ] TUTTO JS in `/assets/js/`
- [ ] NO inline `<style>` tags
- [ ] NO inline `<script>` tags

### Multilingual
- [ ] File `/languages/it/` presente
- [ ] File `/languages/en/` presente
- [ ] Ritornano array associativo
- [ ] Usato in template con `$lang['key']`

### Widget
- [ ] File in `/widgets/` (root level)
- [ ] Registrato con `type='widget'`
- [ ] Ha CSS dedicato
- [ ] Funziona standalone

### Admin Panel
- [ ] Usa AdminLTE 4 layout
- [ ] Include `admin_header_CORRETTO.php`
- [ ] Ha CSS esterno dedicato
- [ ] Ha JS esterno dedicato
- [ ] Tutti endpoints AJAX in `/admin/ajax/`
- [ ] Check session su ogni endpoint

### Database
- [ ] Schema ben progettato
- [ ] Supporta multilingual con `@@it@@...@@en@@...`
- [ ] NO JSON/serialized per dati relazionali
- [ ] Indici appropriati
- [ ] Foreign keys dove necessario

---

## 🚀 Come Usare Questo Template

### Per Creare un Nuovo Plugin:

1. **Copia la struttura directory**
2. **Rinomina tutti i file** (about → nomePlugin)
3. **Sostituisci nei file:**
   - `about` → `nome_plugin`
   - `About` → `NomePlugin`
   - `ABOUT` → `NOME_PLUGIN`
4. **Modifica schema database** in install.php
5. **Aggiorna translation files**
6. **Implementa logica specifica** nel template
7. **Testa installazione/disinstallazione**

### Files da Modificare:

1. `plugin.json` - metadata
2. `install.php` - schema DB e dati default
3. `uninstall.php` - nomi tabelle
4. `languages/*/plugin.php` - traduzioni
5. `templates/index.php` - UI frontend
6. `admin/index.php` - UI admin
7. `widgets/widget-plugin.php` - display widget
8. `assets/css/*.css` - stili
9. `assets/js/*.js` - funzionalità

---

## 📝 Notes & Best Practices

### Database
- Sempre usare `Database::getInstance()`
- Sempre usare prepared statements
- Sempre gestire transazioni per operazioni multiple
- Sempre fare rollback in caso di errore

### Sicurezza
- Sempre check session admin
- Sempre sanitize input con `sanitize()`
- Sempre usare `htmlspecialchars()` in output
- Mai fidarsi di `$_GET`/`$_POST` direttamente

### Performance
- Index su colonne di ordinamento
- LIMIT nelle query
- Evitare N+1 queries
- Cache quando possibile

### Manutenibilità
- Codice commentato
- Funzioni ben nominate
- File organizzati logicamente
- Seguire standard CMS

---

## 📞 Support

Per domande o problemi con questo template:
- **Website:** https://blackangelteam.net
- **Email:** info@blackangelteam.net
- **Version:** 1.0.0
- **Last Updated:** 2024-12-06

---

**Questo plugin è un TEMPLATE REFERENCE per tutti i futuri plugin del CMS.**  
Seguire SEMPRE questa struttura e questi standard!
