<?php
/**
 * About Plugin - Main File
 * Auto-loaded by CMS when plugin is active
 * 
 * Plugin Name: About Us
 * Plugin URI: https://blackangelteam.net
 * Description: Gestisci la pagina Chi Siamo con team members e informazioni aziendali
 * Version: 1.0.0
 * Author: Black Angel Team
 * Author URI: https://blackangelteam.net
 * License: GPL v2 or later
 */

if (!defined('WD_EXEC')) {
    die('Access denied');
}

// Get global variables
global $base_url;

// Plugin constants
define('ABOUT_PLUGIN_DIR', WD_ROOT . '/plugins/about');
define('ABOUT_PLUGIN_URL', $base_url . '/plugins/about');
define('ABOUT_VERSION', '1.0.0');

/**
 * Plugin initialization
 */
function about_init() {
    // Router is automatically loaded by CMS when page contains {{MODULE:about}}
    // No need to include it here (Partners pattern)
}

// Initialize plugin
add_action('init', 'about_init');

/**
 * Add admin menu item
 */
function about_admin_menu() {
    global $admin_menu;
    
    // Load admin translations
    $current_lang = $_SESSION['language'] ?? 'it';
    $admin_lang_file = WD_ROOT . '/plugins/about/languages/' . $current_lang . '/admin/admin_about.php';
    
    if (file_exists($admin_lang_file)) {
        $lang = require $admin_lang_file;
        $menu_title = $lang['admin_menu_title'] ?? 'About Us';
    } else {
        $menu_title = 'About Us';
    }
    
    $admin_menu['plugins']['submenu'][] = [
        'title' => $menu_title,
        'url' => 'plugins/about/admin/index.php',
        'icon' => 'fa-info-circle',
        'permission' => 'admin'
    ];
}

add_action('admin_menu', 'about_admin_menu');

/**
 * Helper function to load About language
 */
function loadAboutLanguage() {
    return loadLanguage('about');
}
