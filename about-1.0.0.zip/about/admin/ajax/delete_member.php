<?php
/**
 * About Plugin - Delete Team Member AJAX
 */

define('WD_EXEC', true);
require_once '../../../../config.php';

header('Content-Type: application/json');

// Check admin session
if (!is_logged_in() || !user_has_role('admin')) {
    echo json_encode(['success' => false, 'message' => 'Non autorizzato']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Metodo non consentito']);
    exit;
}

$db = Database::getInstance();

try {
    $id = (int)($_POST['id'] ?? 0);
    
    if ($id <= 0) {
        throw new Exception('ID non valido');
    }
    
    $stmt = $db->prepare("DELETE FROM about_team WHERE id = ?");
    $stmt->execute([$id]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Membro eliminato con successo'
    ]);
    
} catch (Exception $e) {
    error_log('About delete_member error: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Errore: ' . $e->getMessage()
    ]);
}
