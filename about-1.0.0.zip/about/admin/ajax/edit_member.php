<?php
/**
 * About Plugin - Edit Team Member AJAX
 */

define('WD_EXEC', true);
require_once '../../../../config.php';

header('Content-Type: application/json');

// Check admin session
if (!is_logged_in() || !user_has_role('admin')) {
    echo json_encode(['success' => false, 'message' => 'Non autorizzato']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Metodo non consentito']);
    exit;
}

$db = Database::getInstance();

try {
    $id = (int)($_POST['member_id'] ?? 0);
    $userId = isset($_POST['user_id']) ? (int)$_POST['user_id'] : null;
	//$userId = sanitize($_POST['user_id'] ?? '');
	$name = sanitize($_POST['name'] ?? '');
    $role = sanitize($_POST['role'] ?? '');
    $bio = sanitize($_POST['bio'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $avatar = sanitize($_POST['avatar'] ?? '');
    $useGravatar = isset($_POST['use_gravatar']) && $_POST['use_gravatar'] == '1';
    $isActive = isset($_POST['is_active']) && $_POST['is_active'] == '1' ? 1 : 0;
    
    if ($id <= 0) {
        throw new Exception('ID non valido');
    }
    
    // ⭐ Parse social links JSON (10 social networks)
    $socialLinks = $_POST['social_links'] ?? '{}';
    if (is_string($socialLinks)) {
        $socialArray = json_decode($socialLinks, true);
        if (json_last_error() === JSON_ERROR_NONE) {
            $socialLinks = json_encode($socialArray); // Re-encode clean
        }
    }
    
    // ⭐ Determine final avatar (Local avatar has priority)
    $finalAvatar = '';
    if (!empty($avatar)) {
        // Priority 1: Use custom avatar if provided
        $finalAvatar = $avatar;
    } else if ($useGravatar && !empty($email)) {
        // Priority 2: Use Gravatar if no custom avatar
        $finalAvatar = ''; // Empty means use Gravatar from email
    }
    // Priority 3: Empty (will use placeholder in frontend)
    
    $stmt = $db->prepare("
        UPDATE about_team 
        SET user_id = ?, name = ?, role = ?, bio = ?, avatar = ?, email = ?, social_links = ?, is_active = ?
        WHERE id = ?
    ");
    
    $stmt->execute([$userId, $name, $role, $bio, $finalAvatar, $email, $socialLinks, $isActive, $id]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Membro aggiornato con successo'
    ]);
    
} catch (Exception $e) {
    error_log('About edit_member error: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Errore: ' . $e->getMessage()
    ]);
}
