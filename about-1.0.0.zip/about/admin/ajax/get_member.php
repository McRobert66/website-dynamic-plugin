<?php
/**
 * About Plugin - Get Team Member AJAX
 */

define('WD_EXEC', true);
require_once '../../../../config.php';

header('Content-Type: application/json');

// Check admin session
if (!is_logged_in() || !user_has_role('admin')) {
    echo json_encode(['success' => false, 'message' => 'Non autorizzato']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    echo json_encode(['success' => false, 'message' => 'Metodo non consentito']);
    exit;
}

$db = Database::getInstance();

try {
    $id = (int)($_GET['id'] ?? 0);
    
    if ($id <= 0) {
        throw new Exception('ID non valido');
    }
    
    $stmt = $db->prepare("SELECT * FROM about_team WHERE id = ?");
    $stmt->execute([$id]);
    $member = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$member) {
        throw new Exception('Membro non trovato');
    }
    
    echo json_encode([
        'success' => true,
        'member' => $member
    ]);
    
} catch (Exception $e) {
    error_log('About get_member error: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Errore: ' . $e->getMessage()
    ]);
}
