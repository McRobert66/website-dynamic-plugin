<?php
/**
 * About Plugin - Save Content AJAX
 */

define('WD_EXEC', true);
require_once '../../../../config.php';

header('Content-Type: application/json');

// Check admin session
if (!is_logged_in() || !user_has_role('admin')) {
    echo json_encode(['success' => false, 'message' => 'Non autorizzato']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Metodo non consentito']);
    exit;
}

$db = Database::getInstance();

try {
    $title = sanitize($_POST['title'] ?? '');
    $content = $_POST['content'] ?? ''; // Don't sanitize, keep HTML
    $mission = $_POST['mission'] ?? '';
    $vision = $_POST['vision'] ?? '';
    $foundedYear = (int)($_POST['founded_year'] ?? 0);
    
    $stmt = $db->prepare("
        UPDATE about_content 
        SET title = ?, content = ?, mission = ?, vision = ?, founded_year = ?
        WHERE id = 1
    ");
    
    $stmt->execute([$title, $content, $mission, $vision, $foundedYear]);
    
    echo json_encode([
        'success' => true,
        'message' => 'Contenuto salvato con successo'
    ]);
    
} catch (Exception $e) {
    error_log('About save_content error: ' . $e->getMessage());
    echo json_encode([
        'success' => false,
        'message' => 'Errore: ' . $e->getMessage()
    ]);
}
