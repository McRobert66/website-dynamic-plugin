<?php
/**
 * About Plugin - Admin Panel
 */

define('WD_EXEC', true);
require_once __DIR__ . '/../../../config.php';

// Verifica login
if (!is_logged_in() || !user_has_role('admin')) {
    header('Location: ' . url('admin/login.php'));
    exit;
}

$db = Database::getInstance();

// ============================================
// CARICA TRADUZIONI ADMIN
// ============================================
$current_lang = $_SESSION['language'] ?? 'it';
$admin_lang_file = WD_ROOT . '/plugins/about/languages/' . $current_lang . '/admin/admin_about.php';

if (file_exists($admin_lang_file)) {
    $lang = require $admin_lang_file;
} else {
    // Fallback to Italian
    $lang = require WD_ROOT . '/plugins/about/languages/it/admin/admin_about.php';
}

// ============================================
// HELPER GRAVATAR
// ============================================
/**
 * Get avatar URL with LOCAL AVATAR PRIORITY
 * 
 * @param string|null $email Email for Gravatar
 * @param string|null $avatar Local avatar path/URL
 * @param int $size Avatar size
 * @return string Avatar URL
 */
function get_member_avatar($email = null, $avatar = null, $size = 200) {
    // Priority 1: Local/Custom avatar if provided
    if (!empty($avatar)) {
        // Check if it's a full URL
        if (filter_var($avatar, FILTER_VALIDATE_URL)) {
            return $avatar;
        }
        
        // Local path - convert to URL
        global $base_url;
        if (strpos($avatar, '/') === 0) {
            return $base_url . $avatar;
        }
        return $base_url . '/' . $avatar;
    }
    
    // Priority 2: Gravatar if email exists
    if (!empty($email)) {
        $hash = md5(strtolower(trim($email)));
        return "https://www.gravatar.com/avatar/{$hash}?s={$size}&d=mp";
    }
    
    // Priority 3: Default placeholder
    return 'https://www.gravatar.com/avatar/00000000000000000000000000000000?s=' . $size . '&d=mp';
}

// ============================================
// GET DATA
// ============================================

// Get content
$content = $db->query("SELECT * FROM about_content WHERE id = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);

// Get team members
$teamMembers = $db->query("SELECT * FROM about_team ORDER BY display_order ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC);

// Get stats
$stats = [
    'total_members' => $db->query("SELECT COUNT(*) as count FROM about_team")->fetch(PDO::FETCH_ASSOC)['count'],
    'active_members' => $db->query("SELECT COUNT(*) as count FROM about_team WHERE is_active = 1")->fetch(PDO::FETCH_ASSOC)['count'],
    'inactive_members' => $db->query("SELECT COUNT(*) as count FROM about_team WHERE is_active = 0")->fetch(PDO::FETCH_ASSOC)['count']
];

// ⭐ Get system users with ALL data for dropdown (using real DB structure)
$users = $db->query("
    SELECT 
        id, 
        username, 
        nome,
        cognome,
        email, 
        avatar,
        bio,
        discord,
        steam_id,
        website,
        linkedin_url,
        twitter_url,
        facebook_url,
        instagram_url,
        github_url,
        youtube_url,
        twitch_url,
        tiktok_url
    FROM users 
    WHERE role != 'guest'
    ORDER BY username ASC
")->fetchAll(PDO::FETCH_ASSOC);

// Process users for frontend
foreach ($users as &$user) {
    // Combine nome + cognome into name
    $user['name'] = trim(($user['nome'] ?? '') . ' ' . ($user['cognome'] ?? ''));
    if (empty($user['name'])) {
        $user['name'] = $user['username'];
    }
    
    // Build social_data array from separate columns
    $user['social_data'] = array_filter([
        'twitter' => $user['twitter_url'] ?? '',
        'discord' => $user['discord'] ?? '',
        'steam' => $user['steam_id'] ?? '',
        'github' => $user['github_url'] ?? '',
        'linkedin' => $user['linkedin_url'] ?? '',
        'facebook' => $user['facebook_url'] ?? '',
        'instagram' => $user['instagram_url'] ?? '',
        'youtube' => $user['youtube_url'] ?? '',
        'twitch' => $user['twitch_url'] ?? '',
		'tiktok' => $user['tiktok_url'] ?? '',
        'website' => $user['website'] ?? ''
    ]);
    
    // Get Gravatar URL
    $user['gravatar'] = get_member_avatar($user['email'], null, 200);
    
    // Get final avatar (Gravatar priority)
    $user['final_avatar'] = get_member_avatar($user['email'], $user['avatar'], 200);
}
unset($user);

$icon_page = '<i class="fas fa-info-circle me-2"></i>';
$page_title = $lang['page_title'];
include WD_ROOT . '/admin/includes/header.php';
?>



<?php if (isset($_GET['success'])): ?>
<div class="alert alert-success alert-dismissible fade show">
    <?php echo htmlspecialchars($_GET['success']); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if (isset($_GET['error'])): ?>
<div class="alert alert-danger alert-dismissible fade show">
    <?php echo htmlspecialchars($_GET['error']); ?>
    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- Statistiche -->
<div class="row mb-4">
    <div class="col-lg-4 col-6">
        <div class="small-box text-bg-primary">
            <div class="inner">
                <h3><?php echo $stats['total_members']; ?></h3>
                <p><?php echo $lang['stat_total_members']; ?></p>
            </div>
            <svg class="small-box-icon" fill="currentColor" viewBox="0 0 24 24">
                <path d="M16 11c1.66 0 2.99-1.34 2.99-3S17.66 5 16 5c-1.66 0-3 1.34-3 3s1.34 3 3 3zm-8 0c1.66 0 2.99-1.34 2.99-3S9.66 5 8 5C6.34 5 5 6.34 5 8s1.34 3 3 3zm0 2c-2.33 0-7 1.17-7 3.5V19h14v-2.5c0-2.33-4.67-3.5-7-3.5zm8 0c-.29 0-.62.02-.97.05 1.16.84 1.97 1.97 1.97 3.45V19h6v-2.5c0-2.33-4.67-3.5-7-3.5z"/>
            </svg>
        </div>
    </div>

    <div class="col-lg-4 col-6">
        <div class="small-box text-bg-success">
            <div class="inner">
                <h3><?php echo $stats['active_members']; ?></h3>
                <p><?php echo $lang['stat_active_members']; ?></p>
            </div>
            <svg class="small-box-icon" fill="currentColor" viewBox="0 0 24 24">
                <path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/>
            </svg>
        </div>
    </div>

    <div class="col-lg-4 col-6">
        <div class="small-box text-bg-warning">
            <div class="inner">
                <h3><?php echo $content['founded_year'] ?? '-'; ?></h3>
                <p><?php echo $lang['label_founded_year']; ?></p>
            </div>
            <svg class="small-box-icon" fill="currentColor" viewBox="0 0 24 24">
                <path d="M19 3h-1V1h-2v2H8V1H6v2H5c-1.11 0-1.99.9-1.99 2L3 19c0 1.1.89 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm0 16H5V8h14v11zM7 10h5v5H7z"/>
            </svg>
        </div>
    </div>
</div>

<!-- Tabs Navigation -->
<ul class="nav nav-pills mb-3" id="aboutTabs" role="tablist">
    <li class="nav-item" role="presentation">
        <button class="nav-link active" id="content-tab" data-bs-toggle="pill" data-bs-target="#content" type="button" role="tab">
            <i class="fas fa-file-alt me-2"></i><?php echo $lang['tab_content']; ?>
        </button>
    </li>
    <li class="nav-item" role="presentation">
        <button class="nav-link" id="team-tab" data-bs-toggle="pill" data-bs-target="#team" type="button" role="tab">
            <i class="fas fa-users me-2"></i><?php echo $lang['tab_team']; ?> (<?php echo $stats['total_members']; ?>)
        </button>
    </li>
</ul>

<!-- Tabs Content -->
<div class="tab-content" id="aboutTabsContent">
    
    <!-- TAB CONTENUTO -->
    <div class="tab-pane fade show active" id="content" role="tabpanel">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-edit me-2"></i><?php echo $lang['content_title']; ?></h3>
            </div>
            <form id="content-form" class="card-body">
                <div class="mb-3">
                    <label class="form-label"><?php echo $lang['label_title']; ?> (Multilingua)</label>
                    <input type="text" 
                           name="title" 
                           class="form-control" 
                           value="<?php echo esc_attr($content['title'] ?? ''); ?>"
                           placeholder="<?php echo $lang['placeholder_title']; ?>">
                    <small class="form-text text-muted">Usa formato: @@it@@Testo Italiano@@en@@English Text</small>
                </div>

                <div class="mb-3">
                    <label class="form-label"><?php echo $lang['label_content']; ?> (Multilingua)</label>
                    <textarea name="content" 
                              class="form-control" 
                              rows="5"
                              placeholder="<?php echo $lang['placeholder_content']; ?>"><?php echo esc_html($content['content'] ?? ''); ?></textarea>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo $lang['label_mission']; ?> (Multilingua)</label>
                        <textarea name="mission" 
                                  class="form-control" 
                                  rows="3"
                                  placeholder="<?php echo $lang['placeholder_mission']; ?>"><?php echo esc_html($content['mission'] ?? ''); ?></textarea>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo $lang['label_vision']; ?> (Multilingua)</label>
                        <textarea name="vision" 
                                  class="form-control" 
                                  rows="3"
                                  placeholder="<?php echo $lang['placeholder_vision']; ?>"><?php echo esc_html($content['vision'] ?? ''); ?></textarea>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label"><?php echo $lang['label_founded_year']; ?></label>
                    <input type="number" 
                           name="founded_year" 
                           class="form-control" 
                           value="<?php echo esc_attr($content['founded_year'] ?? ''); ?>"
                           min="1900" 
                           max="<?php echo date('Y'); ?>"
                           placeholder="<?php echo $lang['placeholder_year']; ?>">
                </div>

                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save me-2"></i><?php echo $lang['btn_save']; ?>
                </button>
            </form>
        </div>
    </div>

    <!-- TAB TEAM -->
    <div class="tab-pane fade" id="team" role="tabpanel">
        <div class="card card-primary card-outline">
            <div class="card-header">
                <h3 class="card-title"><i class="fas fa-users me-2"></i><?php echo $lang['team_title']; ?></h3>
                <div class="card-tools">
                    <button type="button" class="btn btn-success btn-sm" data-bs-toggle="modal" data-bs-target="#addMemberModal">
                        <i class="fas fa-plus me-1"></i><?php echo $lang['btn_add_member']; ?>
                    </button>
                </div>
            </div>
            <div class="card-body p-0">
                <?php if (empty($teamMembers)): ?>
                <div class="p-4 text-center text-muted">
                    <i class="fas fa-users fa-3x mb-3"></i>
                    <p><?php echo $lang['no_members']; ?></p>
                    <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#addMemberModal">
                        <i class="fas fa-plus me-1"></i><?php echo $lang['add_first_member']; ?>
                    </button>
                </div>
                <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-striped table-hover mb-0" id="teamTable">
                        <thead>
                            <tr>
                                <th width="60">ID</th>
                                <th width="80"><?php echo $lang['th_avatar']; ?></th>
                                <th><?php echo $lang['th_name']; ?></th>
                                <th><?php echo $lang['th_role']; ?></th>
                                <th width="100" class="text-center"><?php echo $lang['th_status']; ?></th>
                                <th width="150" class="text-center"><?php echo $lang['th_actions']; ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($teamMembers as $member): ?>
                            <tr data-id="<?php echo $member['id']; ?>">
                                <td><?php echo $member['id']; ?></td>
                                <td>
                                    <?php 
                                    // Use helper function with priority: Local > Gravatar > Placeholder
                                    $avatarUrl = get_member_avatar($member['email'], $member['avatar'], 50);
                                    ?>
                                    <img src="<?php echo esc_attr($avatarUrl); ?>" 
                                         class="rounded-circle" 
                                         width="40" 
                                         height="40" 
										 style="height: 40px !important; padding: unset !important; vertical-align: middle;aspect-ratio: auto 40 / 40;" 
                                         alt="<?php echo esc_attr($member['name']); ?>"
                                         onerror="this.src='https://www.gravatar.com/avatar/00000000000000000000000000000000?s=50&d=mp'">
                                </td>
                                <td>
                                    <strong><?php echo esc_html($member['name']); ?></strong>
                                    <?php if ($member['email']): ?>
                                        <br><small class="text-muted"><?php echo esc_html($member['email']); ?></small>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo esc_html($member['role']); ?></td>
                                <td class="text-center">
                                    <?php if ($member['is_active']): ?>
                                        <span class="badge text-bg-success"><?php echo $lang['status_active']; ?></span>
                                    <?php else: ?>
                                        <span class="badge text-bg-secondary"><?php echo $lang['status_inactive']; ?></span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center">
                                    <div class="btn-group btn-group-sm" role="group">
                                        <button type="button" 
                                                class="btn btn-warning btn-edit-member" 
                                                data-id="<?php echo $member['id']; ?>"
                                                data-bs-toggle="tooltip" 
                                                title="Modifica">
                                            <i class="fas fa-edit"></i>
                                        </button>
                                        <button type="button" 
                                                class="btn btn-info btn-toggle-member" 
                                                data-id="<?php echo $member['id']; ?>"
                                                data-bs-toggle="tooltip" 
                                                title="Attiva/Disattiva">
                                            <i class="fas fa-power-off"></i>
                                        </button>
                                        <button type="button" 
                                                class="btn btn-danger btn-delete-member" 
                                                data-id="<?php echo $member['id']; ?>"
                                                data-bs-toggle="tooltip" 
                                                title="Elimina">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal Aggiungi/Modifica Membro -->
<div class="modal fade" id="addMemberModal" tabindex="-1">
    <div class="modal-dialog modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalTitle"><?php echo $lang['modal_title_add']; ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <form id="member-form">
                <input type="hidden" name="member_id" id="member-id">
                <input type="hidden" name="user_id" id="user-id">
                
                <div class="modal-body">
                    
                    <!-- ⭐ Selezione Utente -->
                    <div class="card mb-3">
                        <div class="card-body">
                            <label class="form-label fw-bold">
                                <i class="fas fa-user-circle me-2"></i><?php echo $lang['label_select_user']; ?>
                            </label>
                            <select class="form-select" id="select-user">
                                <option value=""><?php echo $lang['option_select_user']; ?></option>
                                <option value="manual"><?php echo $lang['option_manual']; ?></option>
                                <?php foreach ($users as $user): ?>
                                <option value="<?php echo $user['id']; ?>"
                                        data-name="<?php echo esc_attr($user['name']); ?>"
                                        data-email="<?php echo esc_attr($user['email']); ?>"
                                        data-avatar="<?php echo esc_attr($user['avatar'] ?? ''); ?>"
                                        data-gravatar="<?php echo esc_attr($user['gravatar']); ?>"
                                        data-bio="<?php echo esc_attr($user['bio'] ?? ''); ?>"
                                        data-social='<?php echo esc_attr(json_encode($user['social_data'])); ?>'>
                                    <?php echo esc_html($user['username']); ?>
                                    <?php if ($user['name']): ?>
                                        (<?php echo esc_html($user['name']); ?>)
                                    <?php endif; ?>
                                </option>
                                <?php endforeach; ?>
                            </select>
                            <small class="form-text text-muted">
                                <i class="fas fa-info-circle"></i> <?php echo $lang['help_select_user']; ?>
                            </small>
                        </div>
                    </div>
                    
                    <hr>
                    
                    <!-- ⭐ Preview Avatar -->
                    <div class="card mb-3" id="avatar-preview-card" style="display: none;">
                        <div class="card-body text-center">
                            <label class="form-label fw-bold d-block"><?php echo $lang['label_avatar_preview']; ?></label>
                            <img id="avatar-preview" src="" class="rounded-circle" width="120" height="120" alt="Avatar Preview">
                            <div class="mt-2">
                                <span class="badge bg-info" id="avatar-source"><?php echo $lang['badge_gravatar']; ?></span>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Dati Base -->
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo $lang['label_name']; ?> *</label>
                            <input type="text" name="name" id="member-name" class="form-control" required placeholder="<?php echo $lang['placeholder_name']; ?>">
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label"><?php echo $lang['label_email']; ?></label>
                            <input type="email" name="email" id="member-email" class="form-control" placeholder="<?php echo $lang['placeholder_email']; ?>">
                            <small class="form-text text-muted">
                                <i class="fas fa-info-circle"></i> <?php echo $lang['help_email']; ?>
                            </small>
                        </div>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang['label_role']; ?> * (Multilingua)</label>
                        <input type="text" 
                               name="role" 
                               id="member-role" 
                               class="form-control" 
                               placeholder="<?php echo $lang['placeholder_role']; ?>" 
                               required>
                        <small class="form-text text-muted"><?php echo $lang['help_role_multilang']; ?></small>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label"><?php echo $lang['label_bio']; ?> (Multilingua)</label>
                        <textarea name="bio" 
                                  id="member-bio" 
                                  class="form-control" 
                                  rows="3"
                                  placeholder="<?php echo $lang['placeholder_bio']; ?>"></textarea>
                        <small class="form-text text-muted"><?php echo $lang['help_bio_multilang']; ?></small>
                    </div>
                    
                    <!-- ⭐ Avatar Avanzato -->
                    <div class="card mb-3">
                        <div class="card-header">
                            <h6 class="mb-0">
                                <i class="fas fa-image me-2"></i><?php echo $lang['section_avatar']; ?>
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="alert alert-info small mb-3">
                                <i class="fas fa-info-circle"></i> <?php echo $lang['info_avatar_priority']; ?>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label"><?php echo $lang['label_avatar_url']; ?></label>
                                <input type="text" name="avatar" id="member-avatar" class="form-control" placeholder="<?php echo $lang['placeholder_avatar']; ?>">
                                <small class="form-text text-muted"><?php echo $lang['help_avatar']; ?></small>
                            </div>
                            
                            <div class="form-check">
                                <input type="checkbox" name="use_gravatar" id="use-gravatar" class="form-check-input" value="1" checked>
                                <label class="form-check-label" for="use-gravatar">
                                    <?php echo $lang['label_use_gravatar']; ?>
                                </label>
                            </div>
                        </div>
                    </div>
                    
                    <!-- ⭐ Social Links Completi -->
                    <div class="card mb-3">
                        <div class="card-header">
                            <h6 class="mb-0">
                                <i class="fas fa-share-alt me-2"></i><?php echo $lang['section_social']; ?>
                            </h6>
                        </div>
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">
                                        <i class="fab fa-twitter text-info"></i> <?php echo $lang['label_twitter']; ?>
                                    </label>
                                    <input type="url" name="social_twitter" id="social-twitter" class="form-control" placeholder="<?php echo $lang['placeholder_twitter']; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">
                                        <i class="fab fa-discord text-primary"></i> <?php echo $lang['label_discord']; ?>
                                    </label>
                                    <input type="text" name="social_discord" id="social-discord" class="form-control" placeholder="<?php echo $lang['placeholder_discord']; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">
                                        <i class="fab fa-steam text-dark"></i> <?php echo $lang['label_steam']; ?>
                                    </label>
                                    <input type="url" name="social_steam" id="social-steam" class="form-control" placeholder="<?php echo $lang['placeholder_steam']; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">
                                        <i class="fab fa-github text-dark"></i> <?php echo $lang['label_github']; ?>
                                    </label>
                                    <input type="url" name="social_github" id="social-github" class="form-control" placeholder="<?php echo $lang['placeholder_github']; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">
                                        <i class="fab fa-linkedin text-primary"></i> <?php echo $lang['label_linkedin']; ?>
                                    </label>
                                    <input type="url" name="social_linkedin" id="social-linkedin" class="form-control" placeholder="<?php echo $lang['placeholder_linkedin']; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">
                                        <i class="fab fa-facebook text-primary"></i> <?php echo $lang['label_facebook']; ?>
                                    </label>
                                    <input type="url" name="social_facebook" id="social-facebook" class="form-control" placeholder="<?php echo $lang['placeholder_facebook']; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">
                                        <i class="fab fa-instagram text-danger"></i> <?php echo $lang['label_instagram']; ?>
                                    </label>
                                    <input type="url" name="social_instagram" id="social-instagram" class="form-control" placeholder="<?php echo $lang['placeholder_instagram']; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">
                                        <i class="fab fa-youtube text-danger"></i> <?php echo $lang['label_youtube']; ?>
                                    </label>
                                    <input type="url" name="social_youtube" id="social-youtube" class="form-control" placeholder="<?php echo $lang['placeholder_youtube']; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">
                                        <i class="fab fa-twitch text-purple"></i> <?php echo $lang['label_twitch']; ?>
                                    </label>
                                    <input type="url" name="social_twitch" id="social-twitch" class="form-control" placeholder="<?php echo $lang['placeholder_twitch']; ?>">
                                </div>
								
								<div class="col-md-6 mb-3">
                                    <label class="form-label">
                                        <i class="fab fa-tiktok text-purple"></i> <?php echo $lang['label_tiktok']; ?>
                                    </label>
                                    <input type="url" name="social_tiktok" id="social-tiktok" class="form-control" placeholder="<?php echo $lang['placeholder_tiktok']; ?>">
                                </div>
                                
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">
                                        <i class="fas fa-globe"></i> <?php echo $lang['label_website']; ?>
                                    </label>
                                    <input type="url" name="social_website" id="social-website" class="form-control" placeholder="<?php echo $lang['placeholder_website']; ?>">
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    <!-- Status -->
                    <div class="form-check">
                        <input type="checkbox" name="is_active" id="member-active" class="form-check-input" value="1" checked>
                        <label class="form-check-label" for="member-active">
                            <i class="fas fa-check-circle text-success"></i> <?php echo $lang['label_is_active']; ?>
                        </label>
                    </div>
                    
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        <i class="fas fa-times me-2"></i><?php echo $lang['btn_cancel']; ?>
                    </button>
                    <button type="submit" class="btn btn-primary">
                        <i class="fas fa-save me-2"></i><?php echo $lang['btn_save']; ?>
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- CryptoJS for Gravatar MD5 -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/crypto-js/4.1.1/crypto-js.min.js"></script>
<script src="<?php echo url('plugins/about/assets/js/about-admin.js'); ?>"></script>

<?php include WD_ROOT . '/admin/includes/footer.php'; ?>
