/**
 * About Plugin - Admin JavaScript
 * Vanilla JS - Auto-fill utenti, Gravatar, 10 social networks
 */

document.addEventListener('DOMContentLoaded', function() {
    
    // ============================================
    // SWAL FALLBACK
    // ============================================
    
    /**
     * Safe Swal wrapper - falls back to native alert if SweetAlert2 not loaded
     * IMPORTANT: Uses window.Swal directly to avoid infinite recursion
     */
    const SafeSwal = {
        fire: function(arg1, arg2, arg3) {
            // Check if SweetAlert2 is available
            if (typeof window.Swal !== 'undefined' && window.Swal.fire) {
                // Call ORIGINAL Swal.fire from window object (NOT SafeSwal.fire!)
                if (typeof arg1 === 'object') {
                    return window.Swal.fire(arg1);
                } else {
                    return window.Swal.fire(arg1, arg2, arg3);
                }
            } else {
                // Fallback to native alert
                if (typeof arg1 === 'object') {
                    const message = arg1.html || arg1.text || arg1.title || 'Operazione completata';
                    // Strip HTML tags for alert
                    const cleanMessage = message.replace(/<[^>]*>/g, '').replace(/\n+/g, '\n');
                    alert(cleanMessage);
                } else {
                    const msg = (arg1 || '') + (arg2 ? '\n' + arg2 : '');
                    alert(msg);
                }
                // Return resolved promise to maintain compatibility
                return Promise.resolve({ isConfirmed: true, value: true });
            }
        }
    };
    
    // ============================================
    // USER SELECTION & AUTO-FILL
    // ============================================
    
    const selectUser = document.getElementById('select-user');
    const avatarPreviewCard = document.getElementById('avatar-preview-card');
    const avatarPreview = document.getElementById('avatar-preview');
    const avatarSource = document.getElementById('avatar-source');
    
    if (selectUser) {
        selectUser.addEventListener('change', function() {
            const userId = this.value;
            
            if (userId === '') {
                resetForm();
                return;
            }
            
            if (userId === 'manual') {
                enableManualEntry();
                return;
            }
            
            // Load user data
            const selectedOption = this.options[this.selectedIndex];
            loadUserData(selectedOption);
        });
    }
    
    /**
     * Load all user data from selected option
     */
    function loadUserData(option) {
        // Basic data
        const userName = option.dataset.name;
        const userEmail = option.dataset.email;
        const userAvatar = option.dataset.avatar;
        const userGravatar = option.dataset.gravatar;
        const userBio = option.dataset.bio;
        let socialData = {};
        
        try {
            socialData = JSON.parse(option.dataset.social || '{}');
        } catch (e) {
            socialData = {};
        }
        
        // Fill basic fields
        document.getElementById('user-id').value = option.value;
        document.getElementById('member-name').value = userName || '';
        document.getElementById('member-name').readOnly = true;
        document.getElementById('member-email').value = userEmail || '';
        document.getElementById('member-email').readOnly = true;
        document.getElementById('member-bio').value = userBio || '';
        
        // ⭐ Avatar management (Priority: Local Avatar > Gravatar)
        if (userAvatar) {
            // Priority 1: Show local avatar if present
            avatarPreview.src = userAvatar;
            avatarSource.textContent = 'Avatar Locale';
            avatarSource.classList.remove('bg-info');
            avatarSource.classList.add('bg-secondary');
            avatarPreviewCard.style.display = 'block';
            document.getElementById('member-avatar').value = userAvatar;
            document.getElementById('use-gravatar').checked = false;
        } else if (userGravatar) {
            // Priority 2: Show Gravatar if no local avatar
            avatarPreview.src = userGravatar;
            avatarSource.textContent = 'Gravatar';
            avatarSource.classList.remove('bg-secondary');
            avatarSource.classList.add('bg-info');
            avatarPreviewCard.style.display = 'block';
            document.getElementById('use-gravatar').checked = true;
        }
        
        // ⭐ Load ALL social links
        const socialFields = {
            'twitter': 'social-twitter',
            'discord': 'social-discord',
            'steam': 'social-steam',
            'github': 'social-github',
            'linkedin': 'social-linkedin',
            'facebook': 'social-facebook',
            'instagram': 'social-instagram',
            'youtube': 'social-youtube',
            'twitch': 'social-twitch',
			'tiktok': 'social-tiktok',
            'website': 'social-website'
        };
        
        for (const [social, fieldId] of Object.entries(socialFields)) {
            const field = document.getElementById(fieldId);
            if (field && socialData[social]) {
                field.value = socialData[social];
                field.readOnly = true;
            }
        }
        
        // Focus on role field (only field user needs to fill)
        document.getElementById('member-role').focus();
        
        // Show success message
        const socialCount = Object.keys(socialData).filter(k => socialData[k]).length;
        SafeSwal.fire({
            icon: 'success',
            title: 'Dati Caricati',
            html: '<strong>Tutti i dati utente caricati automaticamente!</strong><br>' +
                  'Avatar: ' + (userGravatar ? 'Gravatar' : 'Locale') + '<br>' +
                  'Social: ' + socialCount + ' link trovati<br><br>' +
                  '<small>Compila solo Ruolo e Bio se necessario</small>',
            timer: 3000,
            showConfirmButton: false
        });
    }
    
    /**
     * Enable manual entry mode
     */
    function enableManualEntry() {
        resetForm();
        document.getElementById('member-name').focus();
        
        SafeSwal.fire({
            icon: 'info',
            title: 'Inserimento Manuale',
            text: 'Compila tutti i campi manualmente',
            timer: 2000,
            showConfirmButton: false
        });
    }
    
    /**
     * Reset form to initial state
     */
    function resetForm() {
        // Reset hidden fields
        document.getElementById('user-id').value = '';
        document.getElementById('member-id').value = '';
        
        // Reset and enable all fields
        const textFields = [
            'member-name', 'member-email', 'member-bio', 
            'member-role', 'member-avatar'
        ];
        
        textFields.forEach(id => {
            const field = document.getElementById(id);
            if (field) {
                field.value = '';
                field.readOnly = false;
            }
        });
        
        // Reset social fields
        document.querySelectorAll('[id^="social-"]').forEach(field => {
            field.value = '';
            field.readOnly = false;
        });
        
        // Hide avatar preview
        avatarPreviewCard.style.display = 'none';
        avatarPreview.src = '';
        
        // Reset checkboxes
        document.getElementById('use-gravatar').checked = true;
        document.getElementById('member-active').checked = true;
    }
    
    // ⭐ Preview avatar on email/avatar change
    const memberEmail = document.getElementById('member-email');
    const memberAvatar = document.getElementById('member-avatar');
    
    if (memberEmail) {
        memberEmail.addEventListener('blur', updateAvatarPreview);
    }
    if (memberAvatar) {
        memberAvatar.addEventListener('blur', updateAvatarPreview);
    }
    
    /**
     * Update avatar preview based on current inputs
     */
    function updateAvatarPreview() {
        const email = document.getElementById('member-email').value;
        const avatar = document.getElementById('member-avatar').value;
        const useGravatar = document.getElementById('use-gravatar').checked;
        
        if (useGravatar && email) {
            // Generate Gravatar URL
            let hash;
            if (typeof CryptoJS !== 'undefined' && CryptoJS.MD5) {
                hash = CryptoJS.MD5(email.toLowerCase().trim()).toString();
            } else {
                // Fallback: use simple hash (not MD5 but works for testing)
                hash = btoa(email.toLowerCase().trim()).substring(0, 32);
            }
            const gravatarUrl = `https://www.gravatar.com/avatar/${hash}?s=200&d=mp`;
            
            avatarPreview.src = gravatarUrl;
            avatarSource.textContent = 'Gravatar';
            avatarSource.classList.remove('bg-secondary');
            avatarSource.classList.add('bg-info');
            avatarPreviewCard.style.display = 'block';
            
        } else if (avatar) {
            avatarPreview.src = avatar;
            avatarSource.textContent = 'Avatar Personalizzato';
            avatarSource.classList.remove('bg-info');
            avatarSource.classList.add('bg-secondary');
            avatarPreviewCard.style.display = 'block';
            
        } else {
            avatarPreviewCard.style.display = 'none';
        }
    }
    
    // ============================================
    // FORM SUBMISSIONS
    // ============================================
    
    // Save content form
    const contentForm = document.getElementById('content-form');
    if (contentForm) {
        contentForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('ajax/save_content.php', {
                method: 'POST',
                body: formData
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    SafeSwal.fire('Salvato!', data.message, 'success');
                } else {
                    SafeSwal.fire('Errore!', data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                SafeSwal.fire('Errore!', 'Errore di connessione', 'error');
            });
        });
    }
    
    // Member form submission
    const memberForm = document.getElementById('member-form');
    if (memberForm) {
        memberForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Build social links JSON
            const socialLinks = {
                twitter: document.getElementById('social-twitter').value,
                discord: document.getElementById('social-discord').value,
                steam: document.getElementById('social-steam').value,
                github: document.getElementById('social-github').value,
                linkedin: document.getElementById('social-linkedin').value,
                facebook: document.getElementById('social-facebook').value,
                instagram: document.getElementById('social-instagram').value,
                youtube: document.getElementById('social-youtube').value,
                twitch: document.getElementById('social-twitch').value,
				tiktok: document.getElementById('social-tiktok').value,
                website: document.getElementById('social-website').value
            };
            
            // Remove empty values
            Object.keys(socialLinks).forEach(key => {
                if (!socialLinks[key]) delete socialLinks[key];
            });
            
            const formData = new FormData();
            formData.append('member_id', document.getElementById('member-id').value);
            formData.append('user_id', document.getElementById('user-id').value);
            formData.append('name', document.getElementById('member-name').value);
            formData.append('email', document.getElementById('member-email').value);
            formData.append('role', document.getElementById('member-role').value);
            formData.append('bio', document.getElementById('member-bio').value);
            formData.append('avatar', document.getElementById('member-avatar').value);
            formData.append('use_gravatar', document.getElementById('use-gravatar').checked ? '1' : '0');
            formData.append('social_links', JSON.stringify(socialLinks));
            formData.append('is_active', document.getElementById('member-active').checked ? '1' : '0');
            
            // Determine endpoint
            const memberId = document.getElementById('member-id').value;
            const endpoint = memberId ? 'ajax/edit_member.php' : 'ajax/add_member.php';
            
            fetch(endpoint, {
                method: 'POST',
                body: formData
            })
            .then(r => r.json())
            .then(data => {
                if (data.success) {
                    SafeSwal.fire({
                        icon: 'success',
                        title: 'Successo!',
                        text: data.message,
                        timer: 2000
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    SafeSwal.fire({
                        icon: 'error',
                        title: 'Errore',
                        text: data.message
                    });
                }
            })
            .catch(error => {
                console.error('Error:', error);
                SafeSwal.fire({
                    icon: 'error',
                    title: 'Errore',
                    text: 'Errore di connessione al server'
                });
            });
        });
    }
    
    // ============================================
    // EDIT MEMBER (Event Delegation)
    // ============================================
    
    // Use event delegation to handle dynamically added buttons
    document.addEventListener('click', function(e) {
        // Check if clicked element is edit button or inside edit button
        const editBtn = e.target.closest('.btn-edit-member');
        if (!editBtn) return;
        
        e.preventDefault();
        const id = editBtn.dataset.id;
        
        if (!id) {
            console.error('Edit button missing data-id attribute');
            SafeSwal.fire('Errore!', 'ID membro non trovato', 'error');
            return;
        }
        
        console.log('Editing member ID:', id);
        
        fetch(`ajax/get_member.php?id=${id}`)
        .then(r => {
            console.log('Response status:', r.status);
            if (!r.ok) {
                throw new Error(`HTTP error! status: ${r.status}`);
            }
            return r.json();
        })
        .then(data => {
            console.log('Member data received:', data);
            
            if (data.success) {
                const m = data.member;
                let social = {};
                
                try {
                    social = JSON.parse(m.social_links || '{}');
                } catch (e) {
                    console.warn('Error parsing social_links:', e);
                    social = {};
                }
                
                document.getElementById('member-id').value = m.id;
                document.getElementById('user-id').value = m.user_id || ''; // ← AGGIUNTO user_id!
                document.getElementById('member-name').value = m.name;
                document.getElementById('member-role').value = m.role;
                document.getElementById('member-bio').value = m.bio || '';
                document.getElementById('member-avatar').value = m.avatar || '';
                document.getElementById('member-email').value = m.email || '';
                
                // If linked to user (user_id present), make name/email readonly
                const isLinkedToUser = m.user_id && m.user_id > 0;
                document.getElementById('member-name').readOnly = isLinkedToUser;
                document.getElementById('member-email').readOnly = isLinkedToUser;
                
                // Update dropdown if linked to user
                if (isLinkedToUser) {
                    const userSelect = document.getElementById('user-select');
                    if (userSelect) {
                        userSelect.value = m.user_id;
                    }
                }
                
                // Fill all social fields
                document.getElementById('social-twitter').value = social.twitter || '';
                document.getElementById('social-discord').value = social.discord || '';
                document.getElementById('social-steam').value = social.steam || '';
                document.getElementById('social-github').value = social.github || '';
                document.getElementById('social-linkedin').value = social.linkedin || '';
                document.getElementById('social-facebook').value = social.facebook || '';
                document.getElementById('social-instagram').value = social.instagram || '';
                document.getElementById('social-youtube').value = social.youtube || '';
                document.getElementById('social-twitch').value = social.twitch || '';
				document.getElementById('social-tiktok').value = social.tiktok || '';
                document.getElementById('social-website').value = social.website || '';
                
                document.querySelector('#addMemberModal .modal-title').textContent = 'Modifica Membro';
                
                const modal = new bootstrap.Modal(document.getElementById('addMemberModal'));
                modal.show();
            } else {
                console.error('API returned success:false', data);
                SafeSwal.fire('Errore!', data.message || 'Errore nel caricamento dati', 'error');
            }
        })
        .catch(error => {
            console.error('Fetch error:', error);
            SafeSwal.fire('Errore!', 'Impossibile caricare i dati del membro. Controlla la console per dettagli.', 'error');
        });
    });
    
    // ============================================
    // DELETE MEMBER (Event Delegation)
    // ============================================
    
    // Use event delegation to handle dynamically added buttons
    document.addEventListener('click', function(e) {
        // Check if clicked element is delete button or inside delete button
        const deleteBtn = e.target.closest('.btn-delete-member');
        if (!deleteBtn) return;
        
        e.preventDefault();
        const id = deleteBtn.dataset.id;
        
        if (!id) {
            console.error('Delete button missing data-id attribute');
            SafeSwal.fire('Errore!', 'ID membro non trovato', 'error');
            return;
        }
        
        console.log('Deleting member ID:', id);
        
        SafeSwal.fire({
            title: 'Sei sicuro?',
            text: 'Vuoi eliminare questo membro?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonText: 'Sì, elimina',
            cancelButtonText: 'Annulla',
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6'
        }).then(result => {
            if (result.isConfirmed) {
                const formData = new FormData();
                formData.append('id', id);
                
                fetch('ajax/delete_member.php', {
                    method: 'POST',
                    body: formData
                })
                .then(r => {
                    console.log('Delete response status:', r.status);
                    if (!r.ok) {
                        throw new Error(`HTTP error! status: ${r.status}`);
                    }
                    return r.json();
                })
                .then(data => {
                    console.log('Delete response:', data);
                    if (data.success) {
                        SafeSwal.fire('Eliminato!', data.message, 'success').then(() => {
                            location.reload();
                        });
                    } else {
                        SafeSwal.fire('Errore!', data.message || 'Impossibile eliminare', 'error');
                    }
                })
                .catch(error => {
                    console.error('Delete error:', error);
                    SafeSwal.fire('Errore!', 'Impossibile eliminare il membro. Controlla la console per dettagli.', 'error');
                });
            }
        });
    });
    
    // ============================================
    // TOGGLE MEMBER STATUS (Event Delegation)
    // ============================================
    
    // Use event delegation to handle dynamically added buttons
    document.addEventListener('click', function(e) {
        // Check if clicked element is toggle button or inside toggle button
        const toggleBtn = e.target.closest('.btn-toggle-member');
        if (!toggleBtn) return;
        
        e.preventDefault();
        const id = toggleBtn.dataset.id;
        
        if (!id) {
            console.error('Toggle button missing data-id attribute');
            SafeSwal.fire('Errore!', 'ID membro non trovato', 'error');
            return;
        }
        
        console.log('Toggling member ID:', id);
        
        const formData = new FormData();
        formData.append('id', id);
        
        fetch('ajax/toggle_member.php', {
            method: 'POST',
            body: formData
        })
        .then(r => {
            console.log('Toggle response status:', r.status);
            if (!r.ok) {
                throw new Error(`HTTP error! status: ${r.status}`);
            }
            return r.json();
        })
        .then(data => {
            console.log('Toggle response:', data);
            if (data.success) {
                // Use SafeSwal or native alert
                if (typeof window.Swal !== 'undefined' && window.Swal.mixin) {
                    const Toast = window.Swal.mixin({
                        toast: true,
                        position: 'top-end',
                        showConfirmButton: false,
                        timer: 2000,
                        timerProgressBar: true
                    });
                    Toast.fire({
                        icon: 'success',
                        title: 'Stato aggiornato'
                    }).then(() => {
                        location.reload();
                    });
                } else {
                    alert('Stato aggiornato!');
                    location.reload();
                }
            } else {
                SafeSwal.fire('Errore!', data.message || 'Impossibile aggiornare lo stato', 'error');
            }
        })
        .catch(error => {
            console.error('Toggle error:', error);
            SafeSwal.fire('Errore!', 'Impossibile aggiornare lo stato. Controlla la console per dettagli.', 'error');
        });
    });
    
    // ============================================
    // RESET FORM ON MODAL CLOSE
    // ============================================
    
    const addMemberModal = document.getElementById('addMemberModal');
    if (addMemberModal) {
        // Reset form when modal is closed
        addMemberModal.addEventListener('hidden.bs.modal', function() {
            resetForm();
            if (selectUser) {
                selectUser.value = '';
            }
            document.querySelector('#addMemberModal .modal-title').textContent = 'Aggiungi Membro Team';
            document.getElementById('member-id').value = '';
        });
        
        // Also reset when modal opens (for ADD mode, not Edit)
        addMemberModal.addEventListener('shown.bs.modal', function() {
            // Only reset if it's ADD mode (member-id is empty)
            if (!document.getElementById('member-id').value) {
                resetForm();
                if (selectUser) {
                    selectUser.value = '';
                }
            }
        });
    }
});
