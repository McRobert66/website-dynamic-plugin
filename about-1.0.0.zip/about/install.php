<?php
/**
 * ABOUT PLUGIN - INSTALLATION SCRIPT
 * 
 * Questo file installa il plugin About nel database:
 * - Registra il plugin nella tabella plugins
 * - Crea le tabelle about_content e about_team
 * - Crea la pagina About
 * - Registra il widget
 * - Aggiunge la voce al menu
 * 
 * @package AboutPlugin
 * @version 1.0.0
 */

if (!defined('WD_EXEC')) {
    die('Direct access not permitted');
}

// Definisci ABOUT_PATH se non è già definito
if (!defined('ABOUT_PATH')) {
    define('ABOUT_PATH', __DIR__);
}

/**
 * Esegue l'installazione del plugin About
 * 
 * @return array Risultato dell'operazione con 'success' e 'message'
 */
function about_install() {
    try {
        $db = Database::getInstance();
        
        // ============================================
        // STEP 0: VERIFICA SE GIÀ INSTALLATO
        // ============================================
        
        $check_existing = $db->query("SELECT id, status FROM plugins WHERE name = 'about' LIMIT 1");
        if ($check_existing && $check_existing->rowCount() > 0) {
            $plugin = $check_existing->fetch(PDO::FETCH_ASSOC);
            
            return [
                'success' => false,
                'error' => 'Plugin About già installato! Disinstallalo prima di reinstallare.',
                'already_installed' => true,
                'plugin_status' => $plugin['status'] ? 'attivo' : 'disattivo'
            ];
        }
        
        // ============================================
        // STEP 1: VERIFICA FILE SQL
        // ============================================
        
        $sql_file = ABOUT_PATH . '/install.sql';
        
        if (!file_exists($sql_file)) {
            return [
                'success' => false, 
                'error' => 'File install.sql non trovato in: ' . $sql_file
            ];
        }
        
        $sql = file_get_contents($sql_file);
        
        if (empty($sql)) {
            return [
                'success' => false, 
                'error' => 'Il file install.sql è vuoto'
            ];
        }
        
        // ============================================
        // STEP 2: PULIZIA E PREPARAZIONE SQL
        // ============================================
        
        // Rimuovi commenti SQL multilinea
        $sql = preg_replace('/\/\*.*?\*\//s', '', $sql);
        
        // Rimuovi commenti SQL singola linea (-- commento)
        $sql = preg_replace('/^--[^\n]*$/m', '', $sql);
        
        // Rimuovi righe vuote multiple
        $sql = preg_replace('/\n\s*\n/', "\n", $sql);
        
        // ============================================
        // STEP 3: DIVISIONE ED ESECUZIONE QUERY
        // ============================================
        
        // Dividi in query separate (attenzione ai ; dentro stringhe)
        $queries = [];
        $current_query = '';
        $in_string = false;
        $string_char = '';
        
        for ($i = 0; $i < strlen($sql); $i++) {
            $char = $sql[$i];
            
            // Gestione stringhe
            if (($char === '"' || $char === "'") && ($i === 0 || $sql[$i-1] !== '\\')) {
                if (!$in_string) {
                    $in_string = true;
                    $string_char = $char;
                } elseif ($char === $string_char) {
                    $in_string = false;
                }
            }
            
            // Divisione query solo se ; è fuori dalle stringhe
            if ($char === ';' && !$in_string) {
                $queries[] = trim($current_query);
                $current_query = '';
            } else {
                $current_query .= $char;
            }
        }
        
        // Aggiungi l'ultima query se presente
        if (!empty(trim($current_query))) {
            $queries[] = trim($current_query);
        }
        
        // Filtra query vuote
        $queries = array_filter($queries, function($query) {
            return !empty(trim($query)) && trim($query) !== '';
        });
        
        // ============================================
        // STEP 4: ESECUZIONE QUERY
        // ============================================
        
        $executed = 0;
        $skipped = 0;
        $errors = [];
        
        foreach ($queries as $index => $query) {
            $query = trim($query);
            
            // Salta query vuote o di configurazione
            if (empty($query) || 
                stripos($query, 'SET FOREIGN_KEY_CHECKS') === 0 ||
                stripos($query, 'SET SQL_MODE') === 0 ||
                stripos($query, 'SET time_zone') === 0) {
                $skipped++;
                continue;
            }
            
            try {
                $db->exec($query);
                $executed++;
            } catch (PDOException $e) {
                // Alcuni errori sono accettabili (es. duplicate entry per dati esempio)
                if (strpos($e->getMessage(), 'Duplicate entry') === false &&
                    strpos($e->getMessage(), 'already exists') === false) {
                    $errors[] = "Query #$index: " . $e->getMessage();
                } else {
                    $skipped++;
                }
            }
        }
        
        // ============================================
        // STEP 5: VERIFICA INSTALLAZIONE
        // ============================================
        
        // Verifica che le tabelle principali esistano
        $required_tables = ['about_content', 'about_team'];
        $missing_tables = [];
        
        foreach ($required_tables as $table) {
            $check = $db->query("SHOW TABLES LIKE '$table'");
            if (!$check || $check->rowCount() === 0) {
                $missing_tables[] = $table;
            }
        }
        
        if (!empty($missing_tables)) {
            return [
                'success' => false,
                'error' => 'Installazione incompleta. Tabelle mancanti: ' . implode(', ', $missing_tables)
            ];
        }
        
        // Verifica plugin registrato
        $check_plugin = $db->query("SELECT id FROM plugins WHERE name = 'about' LIMIT 1");
        if (!$check_plugin || $check_plugin->rowCount() === 0) {
            return [
                'success' => false,
                'error' => 'Plugin non registrato correttamente nella tabella plugins'
            ];
        }
        
        // Verifica pagina creata
        $check_page = $db->query("SELECT id FROM pages WHERE slug = 'about' LIMIT 1");
        if (!$check_page || $check_page->rowCount() === 0) {
            return [
                'success' => false,
                'error' => 'Pagina About non creata correttamente'
            ];
        }
        
        // ============================================
        // STEP 6: INTEGRAZIONE NAVIGATIONMENU
        // ============================================
        
        // Aggiungi traduzioni al plugin NavigationMenu se esiste
        $navmenu_langs = [
            'it' => [
                'file' => WD_ROOT . '/plugins/navigationmenu/languages/it/widget-navigation.php',
                'key' => 'menu_about',
                'value' => 'Chi Siamo'
            ],
            'en' => [
                'file' => WD_ROOT . '/plugins/navigationmenu/languages/en/widget-navigation.php',
                'key' => 'menu_about',
                'value' => 'About Us'
            ]
        ];
        
        $nav_translations_added = 0;
        $nav_translations_errors = [];
        
        foreach ($navmenu_langs as $lang_code => $config) {
            if (file_exists($config['file'])) {
                try {
                    $content = file_get_contents($config['file']);
                    
                    // Verifica se la chiave esiste già (controllo più robusto)
                    if (strpos($content, "'{$config['key']}'") !== false || 
                        strpos($content, "\"{$config['key']}\"") !== false) {
                        continue; // Chiave già presente, salta
                    }
                    
                    // Verifica che il file sia leggibile
                    if (empty($content)) {
                        $nav_translations_errors[] = "File vuoto: {$config['file']}";
                        continue;
                    }
                    
                    // Trova la posizione di chiusura dell'array ]; o );
                    $closingPos = strrpos($content, ');');
                    if ($closingPos === false) {
                        $closingPos = strrpos($content, '];');
                    }
                    
                    if ($closingPos === false) {
                        $nav_translations_errors[] = "Struttura array non valida in: {$config['file']}";
                        continue;
                    }
                    
                    // Verifica se c'è già una virgola finale
                    $beforeClosing = substr($content, 0, $closingPos);
                    
                    // Trova dove finisce realmente l'ultima entry (senza spazi finali)
                    $trimmedBefore = rtrim($beforeClosing);
                    $lastChar = substr($trimmedBefore, -1);
                    
                    // Calcola gli spazi/newline che c'erano tra l'ultima entry e la chiusura
                    $trailingSpaces = substr($beforeClosing, strlen($trimmedBefore));
                    
                    // Crea la nuova voce con o senza virgola iniziale
                    if ($lastChar === ',') {
                        $newEntry = "\n  '{$config['key']}' => '{$config['value']}'";
                    } else if ($lastChar === '[' || $lastChar === '(') {
                        // Array vuoto
                        $newEntry = "\n  '{$config['key']}' => '{$config['value']}'";
                    } else {
                        // Aggiungi virgola prima della nuova voce
                        $newEntry = ",\n  '{$config['key']}' => '{$config['value']}'";
                    }
                    
                    // Inserisci la nuova voce dopo l'ultima entry, poi gli spazi, poi la chiusura
                    $newContent = $trimmedBefore . $newEntry . $trailingSpaces . substr($content, $closingPos);
                    
                    // Scrivi il nuovo contenuto
                    if (file_put_contents($config['file'], $newContent) !== false) {
                        $nav_translations_added++;
                    } else {
                        $nav_translations_errors[] = "Impossibile scrivere su: {$config['file']}";
                    }
                    
                } catch (Exception $e) {
                    $nav_translations_errors[] = "Errore su {$config['file']}: " . $e->getMessage();
                }
            } else {
                $nav_translations_errors[] = "File non trovato: {$config['file']}";
            }
        }
        
        // ============================================
        // STEP 7: RISULTATO FINALE
        // ============================================
        
        if (empty($errors)) {
            $message = "Plugin About installato con successo! Pagina, widget e menu creati.";
            
            // Aggiungi info traduzioni
            if ($nav_translations_added > 0) {
                $message .= " Traduzioni NavigationMenu aggiunte: $nav_translations_added";
            }
            if (!empty($nav_translations_errors)) {
                $message .= " (Warning: " . count($nav_translations_errors) . " errori nelle traduzioni)";
            }
            
            return [
                'success' => true, 
                'message' => $message,
                'stats' => [
                    'queries_executed' => $executed,
                    'queries_skipped' => $skipped,
                    'total_queries' => count($queries),
                    'nav_translations_added' => $nav_translations_added,
                    'nav_translations_errors' => $nav_translations_errors
                ]
            ];
        } else {
            return [
                'success' => false,
                'error' => 'Installazione completata con errori',
                'errors' => $errors,
                'stats' => [
                    'queries_executed' => $executed,
                    'queries_skipped' => $skipped,
                    'total_queries' => count($queries)
                ]
            ];
        }
        
    } catch (PDOException $e) {
        return [
            'success' => false, 
            'error' => 'Errore database: ' . $e->getMessage()
        ];
    } catch (Exception $e) {
        return [
            'success' => false, 
            'error' => 'Errore: ' . $e->getMessage()
        ];
    }
}

// ============================================
// ESECUZIONE INSTALLAZIONE
// ============================================

// Se chiamato direttamente (non da admin panel)
if (basename($_SERVER['PHP_SELF']) === 'install.php') {
    
    // Verifica permessi admin
    if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
        die('Accesso negato: solo gli amministratori possono installare plugin');
    }
    
    $result = about_install();
    
    // Output risultato
    header('Content-Type: application/json');
    echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// Se incluso da altro script, restituisci solo la funzione
return 'about_install';