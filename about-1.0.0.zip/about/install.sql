-- ============================================
-- ABOUT PLUGIN - INSTALLATION SQL
-- ============================================

-- Tabella contenuti About
CREATE TABLE IF NOT EXISTS `about_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text COMMENT 'Supporta...',
  `content` longtext,
  `mission` text,
  `vision` text,
  `founded_year` int(4) DEFAULT NULL,
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Tabella team members
CREATE TABLE IF NOT EXISTS `about_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL COMMENT 'Link opzionale alla tabella users',
  `name` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL COMMENT 'Supporta...',
  `bio` text COMMENT 'Supporta...',
  `avatar` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `social_links` text COMMENT 'JSON: {twitter, discord, steam, github}',
  `display_order` int(11) DEFAULT 0,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_display_order` (`display_order`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Inserisci contenuto predefinito
INSERT INTO `about_content` (`id`, `title`, `content`, `mission`, `vision`, `founded_year`) VALUES
(1, '@@it@@Black Angel Team@@en@@Black Angel Team', 
'@@it@@Siamo un team di appassionati di gaming e tecnologia. Il nostro obiettivo è creare una community accogliente dove tutti possano condividere la passione per i videogiochi.@@en@@We are a team of gaming and technology enthusiasts. Our goal is to create a welcoming community where everyone can share their passion for video games.', 
'@@it@@Creare la migliore gaming community italiana@@en@@Create the best Italian gaming community', 
'@@it@@Diventare un punto di riferimento nel gaming italiano@@en@@Become a reference point in Italian gaming', 
2020);

-- Inserisci membri del team di esempio
INSERT INTO `about_team` (`name`, `role`, `bio`, `avatar`, `display_order`, `is_active`) VALUES
('Admin', '@@it@@Fondatore & CEO@@en@@Founder & CEO', '@@it@@Fondatore del team e appassionato di gaming@@en@@Team founder and gaming enthusiast', NULL, 1, 1),
('Moderator', '@@it@@Community Manager@@en@@Community Manager', '@@it@@Gestisce la community e organizza eventi@@en@@Manages the community and organizes events', NULL, 2, 1);

-- Registra il plugin
INSERT INTO `plugins` (`name`, `display_name`, `description`, `version`, `author`, `status`, `install_date`) VALUES
('about', '@@it@@Chi Siamo@@en@@About Us', '@@it@@Gestisci la pagina Chi Siamo con membri del team, missione, visione e storia@@en@@Manage About Us page with team members, mission, vision and history', '1.0.0', 'Black Angel Team', 1, NOW())
ON DUPLICATE KEY UPDATE status = 1, install_date = NOW();

-- Crea la pagina
INSERT INTO `pages` (`parent_id`, `title`, `slug`, `content`, `status`, `show_in_menu`, `author_id`, `created_at`) VALUES
(0, 'Chi Siamo', 'about', '{{MODULE:about}}', 'published', 1, 1, NOW())
ON DUPLICATE KEY UPDATE status = 'published', show_in_menu = 1;

-- Ottieni l'ID della pagina appena creata (per il menu)
SET @page_id = (SELECT id FROM pages WHERE slug = 'about' LIMIT 1);

-- Registra il widget
INSERT INTO `widgets` (`name`, `title`, `icon`, `content`, `type`, `status`) VALUES
('about', 'Chi Siamo', 'fa-solid fa-info-circle', 'include WD_ROOT . ''/plugins/about/widgets/widget-about.php'';', 'widget', 1)
ON DUPLICATE KEY UPDATE status = 1;

-- Crea voce di menu
INSERT INTO `menu_items` (`parent_id`, `type`, `page_id`, `label`, `url`, `icon`, `target`, `css_class`, `position`, `visibility`, `roles_allowed`, `status`) VALUES
(0, 'page', @page_id, '@@lang@@menu_about@@', NULL, 'fa-solid fa-info-circle', '_self', '', 50, 'all', NULL, 1)
ON DUPLICATE KEY UPDATE page_id = @page_id, status = 1;
