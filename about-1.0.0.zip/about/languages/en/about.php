<?php
/**
 * About Plugin - English Translation
 */

return [
    // General
    'title' => 'About Us',
    'about_us' => 'About Us',
    'our_team' => 'Our Team',
    'founded_in' => 'Founded in',
    'read_more' => 'Read more',
    'view_full_page' => 'View full page',
    
    // Content
    'mission' => 'Mission',
    'vision' => 'Vision',
    'history' => 'History',
    'our_story' => 'Our Story',
    
    // Team
    'team_member' => 'Team Member',
    'team_members' => 'Team Members',
    'meet_team' => 'Meet the Team',
    'role' => 'Role',
    'bio' => 'Biography',
    'contact' => 'Contact',
    'social_links' => 'Social',
    
    // Widget
    'widget_title' => 'About Us Brief',
    'team_count' => 'Members',
    'since' => 'Since',
    
    // Admin
    'admin_title' => 'About Us Management',
    'admin_description' => 'Manage content, team and information of the About Us page',
    'content_tab' => 'Content',
    'team_tab' => 'Team',
    'settings_tab' => 'Settings',
    
    // Content Form
    'page_title' => 'Page Title',
    'page_content' => 'Content',
    'mission_text' => 'Mission Text',
    'vision_text' => 'Vision Text',
    'founded_year' => 'Founded Year',
    'save_content' => 'Save Content',
    
    // Team Form
    'add_member' => 'Add Member',
    'edit_member' => 'Edit Member',
    'member_name' => 'Name',
    'member_role' => 'Role',
    'member_bio' => 'Biography',
    'member_avatar' => 'Avatar URL',
    'member_email' => 'Email',
    'display_order' => 'Display Order',
    'is_active' => 'Active',
    'save_member' => 'Save Member',
    'cancel' => 'Cancel',
    
    // Social
    'twitter' => 'Twitter',
    'discord' => 'Discord',
    'steam' => 'Steam',
    'github' => 'GitHub',
    
    // Actions
    'edit' => 'Edit',
    'delete' => 'Delete',
    'active' => 'Active',
    'inactive' => 'Inactive',
    
    // Messages
    'content_saved' => 'Content saved successfully',
    'member_added' => 'Member added successfully',
    'member_updated' => 'Member updated successfully',
    'member_deleted' => 'Member deleted successfully',
    'status_updated' => 'Status updated successfully',
    'order_updated' => 'Order updated successfully',
    'error_occurred' => 'An error occurred',
    
    // Stats
    'total_members' => 'Total Members',
    'active_members' => 'Active Members',
    'page_views' => 'Page Views',
];
