<?php
/**
 * About Plugin - Admin Translations (English)
 */

return [
    // Page
    'page_title' => 'About Us Management',
    'page_description' => 'Manage About Us page content and team members',
    
    // Stats Cards
    'stat_total_members' => 'Total Team Members',
    'stat_active_members' => 'Active Members',
    'stat_inactive_members' => 'Inactive Members',
    
    // Tabs
    'tab_content' => 'Content',
    'tab_team' => 'Team',
    
    // Content Tab
    'content_title' => 'Edit About Content',
    'label_title' => 'Page Title',
    'label_content' => 'Description',
    'label_mission' => 'Our Mission',
    'label_vision' => 'Our Vision',
    'label_founded_year' => 'Founded Year',
    'placeholder_title' => '@@it@@Italian Title@@en@@English Title',
    'placeholder_content' => '@@it@@Italian description...@@en@@English description...',
    'placeholder_mission' => '@@it@@Our mission...@@en@@Our mission...',
    'placeholder_vision' => '@@it@@Our vision...@@en@@Our vision...',
    'placeholder_year' => 'e.g. 2020',
    
    // Team Tab
    'team_title' => 'Team Management',
    'team_list' => 'Members List',
    'btn_add_member' => 'Add Member',
    'no_members' => 'No members found',
    'add_first_member' => 'Add the first team member',
    
    // Table Headers
    'th_order' => 'Order',
    'th_avatar' => 'Avatar',
    'th_name' => 'Name',
    'th_role' => 'Role',
    'th_email' => 'Email',
    'th_social' => 'Social',
    'th_status' => 'Status',
    'th_actions' => 'Actions',
    
    // Member Form Modal
    'modal_title_add' => 'Add Team Member',
    'modal_title_edit' => 'Edit Member',
    
    // User Selection
    'label_select_user' => 'Select System User',
    'option_select_user' => '-- Select a user --',
    'option_manual' => '✍️ Manual entry',
    'help_select_user' => 'Select a user to automatically load all available data',
    
    // Avatar Preview
    'label_avatar_preview' => 'Avatar Preview',
    'badge_gravatar' => 'Gravatar',
    'badge_local' => 'Local Avatar',
    
    // Basic Fields
    'label_name' => 'Name',
    'label_role' => 'Role',
    'label_bio' => 'Biography',
    'label_email' => 'Email',
    'placeholder_name' => 'Full name',
    'placeholder_role' => '@@it@@Italian Role@@en@@English Role',
    'placeholder_bio' => '@@it@@Italian bio...@@en@@English bio...',
    'placeholder_email' => 'email@example.com',
    'help_email' => 'Used for Gravatar (priority)',
    'help_role_multilang' => 'Supports multilingual format @@it@@...@@en@@',
    'help_bio_multilang' => 'Supports multilingual format @@it@@...@@en@@',
    
    // Avatar Management
    'section_avatar' => 'Avatar Management',
    'label_avatar_url' => 'Avatar URL or Local Path',
    'placeholder_avatar' => 'https://... or /uploads/avatars/...',
    'help_avatar' => 'Examples: https://example.com/avatar.jpg or /uploads/avatars/user.png',
    'label_use_gravatar' => 'Use Gravatar if available (priority)',
    'info_avatar_priority' => '<strong>Avatar Priority:</strong> 1. Gravatar (if email present) → 2. Custom avatar → 3. Default placeholder',
    
    // Social Links
    'section_social' => 'Social Links',
    'label_twitter' => 'Twitter/X',
    'label_discord' => 'Discord',
    'label_steam' => 'Steam',
    'label_github' => 'GitHub',
    'label_linkedin' => 'LinkedIn',
    'label_facebook' => 'Facebook',
    'label_instagram' => 'Instagram',
    'label_youtube' => 'YouTube',
    'label_twitch' => 'Twitch',
    'label_website' => 'Website',
    'placeholder_twitter' => 'https://twitter.com/username',
    'placeholder_discord' => 'username#1234 or invite link',
    'placeholder_steam' => 'https://steamcommunity.com/id/username',
    'placeholder_github' => 'https://github.com/username',
    'placeholder_linkedin' => 'https://linkedin.com/in/username',
    'placeholder_facebook' => 'https://facebook.com/username',
    'placeholder_instagram' => 'https://instagram.com/username',
    'placeholder_youtube' => 'https://youtube.com/@username',
    'placeholder_twitch' => 'https://twitch.tv/username',
    'placeholder_website' => 'https://example.com',
    
    // Status
    'label_is_active' => 'Active',
    'status_active' => 'Active',
    'status_inactive' => 'Inactive',
    
    // Buttons
    'btn_save' => 'Save',
    'btn_cancel' => 'Cancel',
    'btn_edit' => 'Edit',
    'btn_delete' => 'Delete',
    'btn_view_page' => 'View Page',
    
    // Messages
    'content_saved' => 'Content saved successfully',
    'member_added' => 'Member added successfully',
    'member_updated' => 'Member updated successfully',
    'member_deleted' => 'Member deleted successfully',
    'status_updated' => 'Status updated',
    'order_updated' => 'Order updated',
    'error_occurred' => 'An error occurred',
    'error_loading' => 'Error loading data',
    'error_connection' => 'Server connection error',
    
    // Confirmations
    'confirm_delete_title' => 'Are you sure?',
    'confirm_delete_text' => 'Do you want to delete this member?',
    'confirm_delete_yes' => 'Yes, delete',
    'confirm_delete_no' => 'Cancel',
    
    // Toast Messages
    'toast_data_loaded' => 'Data Loaded',
    'toast_data_loaded_msg' => 'All user data loaded automatically!',
    'toast_avatar_source' => 'Avatar',
    'toast_social_found' => 'links found',
    'toast_complete_role' => 'Just fill in Role and Bio if needed',
    'toast_manual_mode' => 'Manual Entry',
    'toast_manual_text' => 'Fill in all fields manually',
    
    // Admin Menu
    'admin_menu_title' => 'About Us',
];
