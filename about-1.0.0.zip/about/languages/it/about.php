<?php
/**
 * About Plugin - Italian Translation
 */

return [
    // General
    'title' => 'Chi Siamo',
    'about_us' => 'Chi Siamo',
    'our_team' => 'Il Nostro Team',
    'founded_in' => 'Fondato nel',
    'read_more' => 'Leggi di più',
    'view_full_page' => 'Visualizza pagina completa',
    
    // Content
    'mission' => 'Missione',
    'vision' => 'Visione',
    'history' => 'Storia',
    'our_story' => 'La Nostra Storia',
    
    // Team
    'team_member' => 'Membro del Team',
    'team_members' => 'Membri del Team',
    'meet_team' => 'Conosci il Team',
    'role' => 'Ruolo',
    'bio' => 'Biografia',
    'contact' => 'Contatto',
    'social_links' => 'Social',
    
    // Widget
    'widget_title' => 'Chi Siamo in Breve',
    'team_count' => 'Membri',
    'since' => 'Dal',
    
    // Admin
    'admin_title' => 'Gestione Chi Siamo',
    'admin_description' => 'Gestisci contenuti, team e informazioni della pagina Chi Siamo',
    'content_tab' => 'Contenuto',
    'team_tab' => 'Team',
    'settings_tab' => 'Impostazioni',
    
    // Content Form
    'page_title' => 'Titolo Pagina',
    'page_content' => 'Contenuto',
    'mission_text' => 'Testo Missione',
    'vision_text' => 'Testo Visione',
    'founded_year' => 'Anno Fondazione',
    'save_content' => 'Salva Contenuto',
    
    // Team Form
    'add_member' => 'Aggiungi Membro',
    'edit_member' => 'Modifica Membro',
    'member_name' => 'Nome',
    'member_role' => 'Ruolo',
    'member_bio' => 'Biografia',
    'member_avatar' => 'Avatar URL',
    'member_email' => 'Email',
    'display_order' => 'Ordine Visualizzazione',
    'is_active' => 'Attivo',
    'save_member' => 'Salva Membro',
    'cancel' => 'Annulla',
    
    // Social
    'twitter' => 'Twitter',
    'discord' => 'Discord',
    'steam' => 'Steam',
    'github' => 'GitHub',
    
    // Actions
    'edit' => 'Modifica',
    'delete' => 'Elimina',
    'active' => 'Attivo',
    'inactive' => 'Non Attivo',
    
    // Messages
    'content_saved' => 'Contenuto salvato con successo',
    'member_added' => 'Membro aggiunto con successo',
    'member_updated' => 'Membro aggiornato con successo',
    'member_deleted' => 'Membro eliminato con successo',
    'status_updated' => 'Stato aggiornato con successo',
    'order_updated' => 'Ordine aggiornato con successo',
    'error_occurred' => 'Si è verificato un errore',
    
    // Stats
    'total_members' => 'Totale Membri',
    'active_members' => 'Membri Attivi',
    'page_views' => 'Visualizzazioni',
];
