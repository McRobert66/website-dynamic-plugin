<?php
/**
 * About Plugin - Admin Translations (Italian)
 */

return [
    // Page
    'page_title' => 'Gestione Chi Siamo',
    'page_description' => 'Gestisci contenuti della pagina Chi Siamo e membri del team',
    
    // Stats Cards
    'stat_total_members' => 'Totale Membri Team',
    'stat_active_members' => 'Membri Attivi',
    'stat_inactive_members' => 'Membri Inattivi',
    
    // Tabs
    'tab_content' => 'Contenuto',
    'tab_team' => 'Team',
    
    // Content Tab
    'content_title' => 'Modifica Contenuto About',
    'label_title' => 'Titolo Pagina',
    'label_content' => 'Descrizione',
    'label_mission' => 'La Nostra Missione',
    'label_vision' => 'La Nostra Visione',
    'label_founded_year' => 'Anno Fondazione',
    'placeholder_title' => '@@it@@Titolo IT@@en@@Title EN',
    'placeholder_content' => '@@it@@Descrizione italiana...@@en@@English description...',
    'placeholder_mission' => '@@it@@La nostra missione...@@en@@Our mission...',
    'placeholder_vision' => '@@it@@La nostra visione...@@en@@Our vision...',
    'placeholder_year' => 'es. 2020',
    
    // Team Tab
    'team_title' => 'Gestione Team',
    'team_list' => 'Lista Membri',
    'btn_add_member' => 'Aggiungi Membro',
    'no_members' => 'Nessun membro presente',
    'add_first_member' => 'Aggiungi il primo membro del team',
    
    // Table Headers
    'th_order' => 'Ordine',
    'th_avatar' => 'Avatar',
    'th_name' => 'Nome',
    'th_role' => 'Ruolo',
    'th_email' => 'Email',
    'th_social' => 'Social',
    'th_status' => 'Stato',
    'th_actions' => 'Azioni',
    
    // Member Form Modal
    'modal_title_add' => 'Aggiungi Membro Team',
    'modal_title_edit' => 'Modifica Membro',
    
    // User Selection
    'label_select_user' => 'Seleziona Utente Sistema',
    'option_select_user' => '-- Seleziona un utente --',
    'option_manual' => '✍️ Inserimento manuale',
    'help_select_user' => 'Seleziona un utente per caricare automaticamente tutti i dati disponibili',
    
    // Avatar Preview
    'label_avatar_preview' => 'Anteprima Avatar',
    'badge_gravatar' => 'Gravatar',
    'badge_local' => 'Avatar Locale',
    
    // Basic Fields
    'label_name' => 'Nome',
    'label_role' => 'Ruolo',
    'label_bio' => 'Biografia',
    'label_email' => 'Email',
    'placeholder_name' => 'Nome completo',
    'placeholder_role' => '@@it@@Ruolo IT@@en@@Role EN',
    'placeholder_bio' => '@@it@@Biografia italiana...@@en@@English bio...',
    'placeholder_email' => 'email@example.com',
    'help_email' => 'Usato per Gravatar (priorità)',
    'help_role_multilang' => 'Supporta multilingua con formato @@it@@...@@en@@',
    'help_bio_multilang' => 'Supporta multilingua con formato @@it@@...@@en@@',
    
    // Avatar Management
    'section_avatar' => 'Gestione Avatar',
    'label_avatar_url' => 'Avatar URL o Percorso Locale',
    'placeholder_avatar' => 'https://... o /uploads/avatars/...',
    'help_avatar' => 'Esempi: https://example.com/avatar.jpg o /uploads/avatars/user.png',
    'label_use_gravatar' => 'Usa Gravatar se disponibile (priorità)',
    'info_avatar_priority' => '<strong>Priorità Avatar:</strong> 1. Gravatar (se email presente) → 2. Avatar personalizzato → 3. Placeholder default',
    
    // Social Links
    'section_social' => 'Link Social',
    'label_twitter' => 'Twitter/X',
    'label_discord' => 'Discord',
    'label_steam' => 'Steam',
    'label_github' => 'GitHub',
    'label_linkedin' => 'LinkedIn',
    'label_facebook' => 'Facebook',
    'label_instagram' => 'Instagram',
    'label_youtube' => 'YouTube',
    'label_twitch' => 'Twitch',
	'label_tiktok' => 'Tiktok',
    'label_website' => 'Sito Web',
    'placeholder_twitter' => 'https://twitter.com/username',
    'placeholder_discord' => 'username#1234 o link invite',
    'placeholder_steam' => 'https://steamcommunity.com/id/username',
    'placeholder_github' => 'https://github.com/username',
    'placeholder_linkedin' => 'https://linkedin.com/in/username',
    'placeholder_facebook' => 'https://facebook.com/username',
    'placeholder_instagram' => 'https://instagram.com/username',
    'placeholder_youtube' => 'https://youtube.com/@username',
    'placeholder_twitch' => 'https://twitch.tv/username',
	'placeholder_tiktok' => 'https://www.tiktok.com/@username',
    'placeholder_website' => 'https://example.com',
    
    // Status
    'label_is_active' => 'Attivo',
    'status_active' => 'Attivo',
    'status_inactive' => 'Inattivo',
    
    // Buttons
    'btn_save' => 'Salva',
    'btn_cancel' => 'Annulla',
    'btn_edit' => 'Modifica',
    'btn_delete' => 'Elimina',
    'btn_view_page' => 'Visualizza Pagina',
    
    // Messages
    'content_saved' => 'Contenuto salvato con successo',
    'member_added' => 'Membro aggiunto con successo',
    'member_updated' => 'Membro aggiornato con successo',
    'member_deleted' => 'Membro eliminato con successo',
    'status_updated' => 'Stato aggiornato',
    'order_updated' => 'Ordine aggiornato',
    'error_occurred' => 'Si è verificato un errore',
    'error_loading' => 'Errore nel caricamento dati',
    'error_connection' => 'Errore di connessione al server',
    
    // Confirmations
    'confirm_delete_title' => 'Sei sicuro?',
    'confirm_delete_text' => 'Vuoi eliminare questo membro?',
    'confirm_delete_yes' => 'Sì, elimina',
    'confirm_delete_no' => 'Annulla',
    
    // Toast Messages
    'toast_data_loaded' => 'Dati Caricati',
    'toast_data_loaded_msg' => 'Tutti i dati utente caricati automaticamente!',
    'toast_avatar_source' => 'Avatar',
    'toast_social_found' => 'link trovati',
    'toast_complete_role' => 'Compila solo Ruolo e Bio se necessario',
    'toast_manual_mode' => 'Inserimento Manuale',
    'toast_manual_text' => 'Compila tutti i campi manualmente',
    
    // Admin Menu
    'admin_menu_title' => 'Chi Siamo',
];
