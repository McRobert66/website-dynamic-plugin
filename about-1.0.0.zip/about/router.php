<?php
/**
 * About Plugin - Router
 * Gestisce il routing della pagina about
 */

if (!defined('WD_EXEC')) die('Access Denied');

// About ha solo una pagina, carica il template
require_once __DIR__ . '/templates/index.php';
