<?php
/**
 * About Plugin - Template Lista About
 */

if (!defined('WD_EXEC')) die('Access Denied');

// Get database
$db = Database::getInstance();

// Get content
$content = $db->query("SELECT * FROM about_content WHERE id = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);

// Get active team members
$teamMembers = $db->query("SELECT * FROM about_team WHERE is_active = 1 ORDER BY display_order ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC);

// ⭐ Helper for avatar with priority: Local > Gravatar > Placeholder
function display_member_avatar($member, $size = 120) {
    $email = $member['email'] ?? '';
    $avatar = $member['avatar'] ?? '';
    
    // Priority 1: Custom local avatar (if present)
    if (!empty($avatar)) {
        // Full URL (starts with http:// or https://)
        if (filter_var($avatar, FILTER_VALIDATE_URL)) {
            return $avatar;
        }
        // Relative path - convert to absolute URL
        global $base_url;
        return $base_url . '/' . ltrim($avatar, '/');
    }
    
    // Priority 2: Gravatar (if email exists)
    if (!empty($email)) {
        $hash = md5(strtolower(trim($email)));
        return "https://www.gravatar.com/avatar/{$hash}?s={$size}&d=mp";
    }
    
    // Priority 3: Default placeholder
    return "https://www.gravatar.com/avatar/00000000000000000000000000000000?s={$size}&d=mp";
}

// Helper for multilingual content (DB pattern @@it@@...@@en@@...)
function get_translated_text($text) {
    if (empty($text)) return '';
    $lang = $_SESSION['language'] ?? 'it';
    $pattern = '/@@' . $lang . '@@(.*?)(?:@@|$)/s';
    if (preg_match($pattern, $text, $matches)) {
        return trim($matches[1]);
    }
    if ($lang !== 'it' && preg_match('/@@it@@(.*?)(?:@@|$)/s', $text, $matches)) {
        return trim($matches[1]);
    }
    return $text;
}
?>

<div class="about-page">
    <div class="container">
        
        <!-- Page Header -->
        <div class="about-header text-center mb-4">
            <h1 class="about-title">
                <i class="fas fa-info-circle text-primary"></i> 
                <?php echo esc_html(get_translated_text($content['title'] ?? 'Chi Siamo')); ?>
            </h1>
            <?php if (!empty($content['founded_year'])): ?>
            <p class="about-subtitle text-muted">
                Fondato nel <?php echo (int)$content['founded_year']; ?>
            </p>
            <?php endif; ?>
        </div>

        <!-- Main Content -->
        <?php if ($content): ?>
        <div class="about-content mb-5">
            
                
                <!-- Description -->
                
                    <div class="card shadow-sm mb-4">
                        <div class="card-body">
                            <h3 class="card-title"><i class="fa-regular fa-address-card"></i> Chi Siamo</h3>
                            <div class="about-text">
                                <?php echo nl2br(get_translated_text($content['content'])); ?>
                            </div>
                        </div>
                    </div>
                

                <!-- Mission & Vision -->
                <div class="col">
                    <?php if (!empty($content['mission'])): ?>
                    <div class="card shadow-sm mb-3">
                        <div class="card-body">
                            <h5 class="card-title">
                                <i class="fas fa-bullseye text-primary"></i> La Nostra Missione
                            </h5>
                            <p class="card-text"><?php echo esc_html(get_translated_text($content['mission'])); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>

                    <?php if (!empty($content['vision'])): ?>
                    <div class="card shadow-sm">
                        <div class="card-body">
                            <h5 class="card-title">
                                <i class="fas fa-eye text-success"></i> La Nostra Visione
                            </h5>
                            <p class="card-text"><?php echo esc_html(get_translated_text($content['vision'])); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            
        </div>
        <?php endif; ?>

        <!-- Team Section -->
        <?php if (!empty($teamMembers)): ?>
        <div class="team-section">
            <h2 class="section-title text-center mb-4">
                <i class="fas fa-users text-primary"></i> Il Nostro Team
            </h2>
            
            <div class="row justify-content-center">
                <?php foreach ($teamMembers as $member): ?>
                <div class="col-md-6 col-lg-4 mb-4">
                    <div class="card team-member-card h-100 shadow-sm">
                        <div class="card-body text-center">
                            <!-- Avatar -->
							<a href="/?page=users&id=<?php echo esc_attr($member['user_id']); ?>">
                            <div class="team-avatar mb-3">
                                <img src="<?php echo display_member_avatar($member, 200); ?>" 
                                     class="rounded-circle" 
                                     width="120" 
                                     height="120"
                                     alt="<?php echo esc_attr($member['name']); ?>"
                                     onerror="this.src='https://www.gravatar.com/avatar/00000000000000000000000000000000?s=200&d=mp'"
                                     loading="lazy">
                            </div>
							</a>
                            
                            <!-- Name & Role -->
                            <h5 class="card-title mb-1"><?php echo esc_html($member['name']); ?></h5>
                            <p class="text-muted mb-3"><?php echo esc_html(get_translated_text($member['role'])); ?></p>
                            
                            <!-- Bio -->
                            <?php if (!empty($member['bio'])): ?>
                            <p class="card-text small">
                                <?php echo esc_html(get_translated_text($member['bio'])); ?>
                            </p>
                            <?php endif; ?>
                            
                            <!-- Social Links -->
                            <?php if (!empty($member['social_links'])): 
                                $social = json_decode($member['social_links'], true);
                                if (is_array($social) && !empty(array_filter($social))):
                            ?>
                            <div class="social-links mt-3">
                                <?php if (!empty($social['twitter'])): ?>
                                <a href="<?php echo esc_attr($social['twitter']); ?>" 
                                   class="btn btn-sm btn-outline-info" 
                                   target="_blank" 
                                   rel="noopener">
                                    <i class="fab fa-twitter"></i>
                                </a>
                                <?php endif; ?>
                                
                                <?php if (!empty($social['discord'])): ?>
                                <a href="<?php echo esc_attr($social['discord']); ?>" 
                                   class="btn btn-sm btn-outline-primary" 
                                   target="_blank" 
                                   rel="noopener">
                                    <i class="fab fa-discord"></i>
                                </a>
                                <?php endif; ?>
                                
                                <?php if (!empty($social['steam'])): ?>
                                <a href="<?php echo esc_attr($social['steam']); ?>" 
                                   class="btn btn-sm btn-outline-secondary" 
                                   target="_blank" 
                                   rel="noopener">
                                    <i class="fab fa-steam"></i>
                                </a>
                                <?php endif; ?>
                                
                                <?php if (!empty($social['github'])): ?>
                                <a href="<?php echo esc_attr($social['github']); ?>" 
                                   class="btn btn-sm btn-outline-secondary" 
                                   target="_blank" 
                                   rel="noopener">
                                    <i class="fab fa-github"></i>
                                </a>
                                <?php endif; ?>
                                
                                <?php if (!empty($social['linkedin'])): ?>
                                <a href="<?php echo esc_attr($social['linkedin']); ?>" 
                                   class="btn btn-sm btn-outline-primary" 
                                   target="_blank" 
                                   rel="noopener">
                                    <i class="fab fa-linkedin"></i>
                                </a>
                                <?php endif; ?>
                                
                                <?php if (!empty($social['facebook'])): ?>
                                <a href="<?php echo esc_attr($social['facebook']); ?>" 
                                   class="btn btn-sm btn-outline-primary" 
                                   target="_blank" 
                                   rel="noopener">
                                    <i class="fab fa-facebook"></i>
                                </a>
                                <?php endif; ?>
                                
                                <?php if (!empty($social['instagram'])): ?>
                                <a href="<?php echo esc_attr($social['instagram']); ?>" 
                                   class="btn btn-sm btn-outline-danger" 
                                   target="_blank" 
                                   rel="noopener">
                                    <i class="fab fa-instagram"></i>
                                </a>
                                <?php endif; ?>
                                
                                <?php if (!empty($social['youtube'])): ?>
                                <a href="<?php echo esc_attr($social['youtube']); ?>" 
                                   class="btn btn-sm btn-outline-danger" 
                                   target="_blank" 
                                   rel="noopener">
                                    <i class="fab fa-youtube"></i>
                                </a>
                                <?php endif; ?>
                                
                                <?php if (!empty($social['twitch'])): ?>
                                <a href="<?php echo esc_attr($social['twitch']); ?>" 
                                   class="btn btn-sm btn-outline-purple" 
                                   target="_blank" 
                                   rel="noopener">
                                    <i class="fab fa-twitch"></i>
                                </a>
                                <?php endif; ?>
                                
                                <?php if (!empty($social['tiktok'])): ?>
                                <a href="<?php echo esc_attr($social['tiktok']); ?>" 
                                   class="btn btn-sm btn-outline-dark" 
                                   target="_blank" 
                                   rel="noopener">
                                    <i class="fab fa-tiktok"></i>
                                </a>
                                <?php endif; ?>
                                
                                <?php if (!empty($social['website'])): ?>
                                <a href="<?php echo esc_attr($social['website']); ?>" 
                                   class="btn btn-sm btn-outline-success" 
                                   target="_blank" 
                                   rel="noopener">
                                    <i class="fas fa-globe"></i>
                                </a>
                                <?php endif; ?>
                            </div>
                            <?php endif; endif; ?>
                            
                            <!-- Email -->
                            <?php if (!empty($member['email'])): ?>
                            <div class="mt-3">
                                <a href="mailto:<?php echo esc_attr($member['email']); ?>" 
                                   class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-envelope"></i> Contatta
                                </a>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php else: ?>
        <div class="team-empty text-center py-5">
            <i class="fas fa-users fa-4x text-muted mb-3"></i>
            <h4 class="text-muted">Nessun membro del team</h4>
        </div>
        <?php endif; ?>
        
    </div>
</div>
