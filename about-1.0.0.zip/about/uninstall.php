<?php
/**
 * ABOUT PLUGIN - UNINSTALLATION SCRIPT
 * 
 * Rimuove completamente il plugin About dal database:
 * - Elimina le tabelle about_content e about_team
 * - Rimuove il plugin dalla tabella plugins
 * - Rimuove la pagina About
 * - Rimuove il widget
 * - Rimuove la voce dal menu
 * - Rimuove le traduzioni dal NavigationMenu
 * 
 * @package AboutPlugin
 * @version 1.0.0
 */

if (!defined('WD_EXEC')) {
    die('Direct access not permitted');
}

/**
 * Esegue la disinstallazione del plugin About
 * 
 * @return array Risultato dell'operazione con 'success' e 'message'
 */
function about_uninstall() {
    try {
        $db = Database::getInstance();
        
        $errors = [];
        $deleted = 0;
        
        // ============================================
        // STEP 1: ELIMINA TABELLE
        // ============================================
        
        $tables = ['about_content', 'about_team'];
        
        foreach ($tables as $table) {
            try {
                $db->exec("DROP TABLE IF EXISTS `$table`");
                $deleted++;
            } catch (PDOException $e) {
                $errors[] = "Errore eliminazione tabella $table: " . $e->getMessage();
            }
        }
        
        // ============================================
        // STEP 2: RIMUOVI PLUGIN DALLA TABELLA
        // ============================================
        
        try {
            // Prima verifica se esiste
            $check = $db->query("SELECT id FROM plugins WHERE name = 'about' LIMIT 1");
            $plugin_exists = $check && $check->rowCount() > 0;
            
            if ($plugin_exists) {
                $stmt = $db->prepare("DELETE FROM plugins WHERE name = ?");
                $stmt->execute(['about']);
                
                // Verifica che sia stato effettivamente eliminato
                $verify = $db->query("SELECT id FROM plugins WHERE name = 'about' LIMIT 1");
                if ($verify && $verify->rowCount() === 0) {
                    $deleted++;
                } else {
                    $errors[] = "Plugin 'about' non rimosso dalla tabella plugins (verifica fallita)";
                }
            }
        } catch (PDOException $e) {
            $errors[] = "Errore rimozione plugin: " . $e->getMessage();
        }
        
        // ============================================
        // STEP 3: RIMUOVI PAGINA E MENU
        // ============================================
        
        try {
            // Ottieni ID della pagina prima di eliminarla
            $stmt = $db->query("SELECT id FROM pages WHERE slug = 'about' LIMIT 1");
            $page = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($page) {
                $page_id = $page['id'];
                
                // ============================================
                // STEP 3A: PULISCI TRACKING (page_views, user_activity)
                // ============================================
                
                try {
                    // Pulisci page_views (usa page_url, NON page_id!)
                    $db->exec("DELETE FROM `page_views` WHERE page_url LIKE '%about%'");
                    $db->exec("DELETE FROM `page_views` WHERE page_title LIKE '%About%'");
                    
                    // Pulisci user_activity (usa current_page, NON page_id!)
                    $db->exec("DELETE FROM `user_activity` WHERE current_page LIKE '%about%'");
                    $db->exec("DELETE FROM `user_activity` WHERE page_title LIKE '%About%'");
                    
                    $deleted++;
                } catch (PDOException $e) {
                    // Non è critico se queste tabelle non esistono
                    $errors[] = "Warning rimozione tracking: " . $e->getMessage();
                }
                
                // Elimina voci menu collegate
                $db->exec("DELETE FROM `menu_items` WHERE page_id = $page_id");
                
                // Elimina page_widgets collegati
                $db->exec("DELETE FROM `page_widgets` WHERE page_id = $page_id");
                
                // Elimina la pagina
                $db->exec("DELETE FROM `pages` WHERE id = $page_id");
                
                $deleted += 2;
            }
        } catch (PDOException $e) {
            $errors[] = "Errore rimozione pagina/menu: " . $e->getMessage();
        }
        
        // ============================================
        // STEP 4: RIMUOVI WIDGET
        // ============================================
        
        try {
            // Rimuovi widget
            $db->exec("DELETE FROM `widgets` WHERE name = 'about'");
            
            // Rimuovi assegnazioni widget (se la tabella esiste)
            $check = $db->query("SHOW TABLES LIKE 'widget_assignments'");
            if ($check && $check->rowCount() > 0) {
                $db->exec("DELETE FROM `widget_assignments` WHERE widget_name = 'about'");
            }
            
            $deleted++;
        } catch (PDOException $e) {
            $errors[] = "Errore rimozione widget: " . $e->getMessage();
        }
        
        // ============================================
        // STEP 5: RIMUOVI TRADUZIONI NAVIGATIONMENU
        // ============================================
        
        $nav_translations_removed = 0;
        $nav_translations_errors = [];
        
        $navmenu_langs = [
            'it' => WD_ROOT . '/plugins/navigationmenu/languages/it/widget-navigation.php',
            'en' => WD_ROOT . '/plugins/navigationmenu/languages/en/widget-navigation.php'
        ];
        
        foreach ($navmenu_langs as $lang_code => $file_path) {
            if (file_exists($file_path)) {
                try {
                    $content = file_get_contents($file_path);
                    
                    // Verifica se la chiave 'menu_about' esiste
                    if (strpos($content, "'menu_about'") !== false || 
                        strpos($content, '"menu_about"') !== false) {
                        
                        // Rimuovi la riga con menu_about (pattern più robusto)
                        // Pattern: qualsiasi spazio, 'menu_about' => 'qualsiasi cosa', con o senza virgola finale
                        $patterns = [
                            "/\s*'menu_about'\s*=>\s*'[^']*'\s*,?\s*\n/",  // Con apici singoli
                            '/\s*"menu_about"\s*=>\s*"[^"]*"\s*,?\s*\n/',  // Con apici doppi
                        ];
                        
                        $modified = false;
                        foreach ($patterns as $pattern) {
                            if (preg_match($pattern, $content)) {
                                $newContent = preg_replace($pattern, '', $content);
                                
                                // Scrivi il nuovo contenuto
                                if (file_put_contents($file_path, $newContent) !== false) {
                                    $nav_translations_removed++;
                                    $modified = true;
                                    break;
                                }
                            }
                        }
                        
                        if (!$modified && (strpos($content, "'menu_about'") !== false || strpos($content, '"menu_about"') !== false)) {
                            $nav_translations_errors[] = "Chiave menu_about presente in $file_path ma non rimossa";
                        }
                    }
                } catch (Exception $e) {
                    $nav_translations_errors[] = "Errore su $file_path: " . $e->getMessage();
                }
            }
        }
        
        // ============================================
        // STEP 6: RISULTATO FINALE
        // ============================================
        
        if (empty($errors)) {
            $message = "Plugin About disinstallato con successo! Tabelle, pagina, widget e menu rimossi.";
            
            // Aggiungi info traduzioni
            if ($nav_translations_removed > 0) {
                $message .= " Traduzioni NavigationMenu rimosse: $nav_translations_removed";
            }
            if (!empty($nav_translations_errors)) {
                $message .= " (Warning: " . count($nav_translations_errors) . " errori nelle traduzioni)";
            }
            
            return [
                'success' => true,
                'message' => $message,
                'stats' => [
                    'items_deleted' => $deleted,
                    'nav_translations_removed' => $nav_translations_removed,
                    'nav_translations_errors' => $nav_translations_errors
                ]
            ];
        } else {
            return [
                'success' => false,
                'error' => 'Disinstallazione completata con errori',
                'errors' => $errors,
                'stats' => [
                    'items_deleted' => $deleted,
                    'nav_translations_removed' => $nav_translations_removed,
                    'nav_translations_errors' => $nav_translations_errors
                ]
            ];
        }
        
    } catch (PDOException $e) {
        return [
            'success' => false,
            'error' => 'Errore database: ' . $e->getMessage()
        ];
    } catch (Exception $e) {
        return [
            'success' => false,
            'error' => 'Errore: ' . $e->getMessage()
        ];
    }
}

// ============================================
// ESECUZIONE DISINSTALLAZIONE
// ============================================

// Se chiamato direttamente (non da admin panel)
if (basename($_SERVER['PHP_SELF']) === 'uninstall.php') {
    
    // Verifica permessi admin
    if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
        die('Accesso negato: solo gli amministratori possono disinstallare plugin');
    }
    
    $result = about_uninstall();
    
    // Output risultato
    header('Content-Type: application/json');
    echo json_encode($result, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

// Se incluso da altro script, restituisci solo la funzione
return 'about_uninstall';