<?php
/**
 * About Plugin - Widget Display
 * Mostra breve introduzione con link alla pagina completa
 */

if (!defined('WD_EXEC')) {
    die('Access denied');
}

// Load translations manually (same pattern as navigation menu)
if (!isset($GLOBALS['aboutLang'])) {
    $GLOBALS['aboutLang'] = [];
    $current_lang = $_SESSION['language'] ?? 'it';
    
    // Try plugin language folder first
    $localLangFile = WD_ROOT . '/plugins/about/languages/' . $current_lang . '/about.php';
    // Fallback to global language folder
    $globalLangFile = WD_ROOT . '/languages/' . $current_lang . '/about.php';
    
    if (file_exists($localLangFile)) {
        $GLOBALS['aboutLang'] = require $localLangFile;
    } elseif (file_exists($globalLangFile)) {
        $GLOBALS['aboutLang'] = require $globalLangFile;
    } else {
        // Fallback to Italian if language file not found
        $fallbackFile = WD_ROOT . '/plugins/about/languages/it/about.php';
        if (file_exists($fallbackFile)) {
            $GLOBALS['aboutLang'] = require $fallbackFile;
        }
    }
}

// Shorthand for accessing translations
$lang = $GLOBALS['aboutLang'];

// Get database
$db = Database::getInstance();

// Get content
$content = $db->query("SELECT * FROM about_content WHERE id = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);

// Get active team members count
$teamCount = $db->query("SELECT COUNT(*) as count FROM about_team WHERE is_active = 1")->fetch(PDO::FETCH_ASSOC);

// Get base URL for assets
global $base_url;
?>


<div class="card shadow-sm mb-4">
    <div class="card-header">
        <h5 class="card-title mb-0"><i class="fas fa-info-circle"></i> <?php echo $lang['widget_title']; ?></h5>
    </div>
    
    <div class="card-body">
        <?php if ($content): ?>
            <div class="widget-about-intro">
                <?php 
                // Get translated content
                $introText = translateText($content['content']);
                // Limit to 200 characters
                $shortIntro = mb_substr(strip_tags($introText), 0, 200);
                if (mb_strlen($introText) > 200) {
                    $shortIntro .= '...';
                }
                echo $shortIntro;
                ?>
            </div>
            
            <div class="widget-about-stats">
                <?php if ($content['founded_year']): ?>
                <div class="widget-about-stat">
                    <span class="widget-about-stat-value"><?php echo $content['founded_year']; ?></span>
                    <span class="widget-about-stat-label"><?php echo $lang['since']; ?></span>
                </div>
                <?php endif; ?>
                
                <div class="widget-about-stat">
                    <span class="widget-about-stat-value"><?php echo $teamCount['count']; ?></span>
                    <span class="widget-about-stat-label"><?php echo $lang['team_count']; ?></span>
                </div>
            </div>
            
            <div>
                <a href="?page=about" class="btn btn-outline-primary btn-xs">
                    <i class="fas fa-arrow-right"></i> <?php echo $lang['view_full_page']; ?>
                </a>
            </div>
        <?php else: ?>
            <p class="text-muted text-center">
                <i class="fas fa-exclamation-triangle"></i>
                <?php echo $lang['error_occurred']; ?>
            </p>
        <?php endif; ?>
    </div>
</div>
